function gps_gui_simulator()
% GPS_GUI_SIMULATOR  Interactive GPS dynamics simulator (MATLAB, single file).
%
%   Run:  >> gps_gui_simulator
%
%   Tab 1  - GPS equations rendered with the LaTeX interpreter
%   Tab 2  - The MATLAB functions that implement those equations (source is
%            read live from this file) plus an explanation of each
%   Tab 3  - Real-time 3D animation: 24 satellites, a moving user,
%            pseudorange lines, least-squares position fix, error and GDOP
%
%   Units: km, s, rad (internally).  Frame: Earth-centred inertial (ECI);
%   the user rides on the rotating Earth.  Tested design target: R2019b+.

%% =====================================================================
%  SECTION 1 - CONSTANTS AND CONSTELLATION DEFINITION (simulation logic)
%  =====================================================================
C.c   = 299792.458;          % speed of light [km/s]
C.Re  = 6371;                % Earth radius [km]
C.mu  = 398600.4418;         % Earth gravitational parameter [km^3/s^2]
C.we  = 7.2921159e-5;        % Earth rotation rate [rad/s]
C.a   = 26560;               % GPS orbit semi-major axis [km]
C.inc = deg2rad(55);         % orbital inclination [rad]

nPlanes = 6;  satsPerPlane = 4;                       % 24-satellite Walker-like set
raanDeg = repelem((0:nPlanes-1)*60, satsPerPlane);    % plane RAAN [deg]
M0Deg   = repmat((0:satsPerPlane-1)*90, 1, nPlanes) ...
        + repelem((0:nPlanes-1)*15, satsPerPlane);    % initial phase [deg]
cn.raan = deg2rad(raanDeg(:));
cn.M0   = deg2rad(M0Deg(:));
cn.n    = sqrt(C.mu / C.a^3);                         % mean motion [rad/s]
nSat    = numel(cn.raan);

%% =====================================================================
%  SECTION 2 - RUN-TIME STATE SHARED BY ALL CALLBACKS (simulation logic)
%  =====================================================================
running = false;             % animation flag
t       = 0;                 % simulation time [s]
lat     = deg2rad(10);       % user latitude  [rad]
lon     = deg2rad(106);      % user longitude [rad]
xPrev   = zeros(4,1);        % last estimate [x y z b] (b = c*dt_u in km)
trail   = zeros(0,3);        % true-position trail (3D)
enuHist = zeros(0,2);        % east/north error history [m]
tHist   = zeros(0,1);        % time history [s]
errHist = zeros(0,1);        % 3D position error history [m]
gdHist  = zeros(0,1);        % GDOP history

%% =====================================================================
%  SECTION 3 - GUI DESIGN: figure, tab group, tabs
%  =====================================================================
bg  = [0.96 0.96 0.97];
fig = figure('Name','GPS Dynamics Simulator','NumberTitle','off', ...
    'Units','normalized','Position',[0.04 0.05 0.92 0.86], ...
    'Color',bg,'MenuBar','none','CloseRequestFcn',@onClose);
tabs   = uitabgroup(fig,'Units','normalized','Position',[0 0 1 1]);
tabEq  = uitab(tabs,'Title','1. Equations (LaTeX)','BackgroundColor','w');
tabFn  = uitab(tabs,'Title','2. MATLAB Functions','BackgroundColor',bg);
tabSim = uitab(tabs,'Title','3. Live Simulation','BackgroundColor',bg);
tabs.SelectedTab = tabSim;

%% =====================================================================
%  SECTION 4 - LATEX INTEGRATION: equations drawn with the latex interpreter
%  =====================================================================
% A full-tab invisible axes acts as a canvas; every equation is a text()
% object whose 'Interpreter' is 'latex', so no external toolbox is needed.
axEq = axes('Parent',tabEq,'Position',[0 0 1 1],'Visible','off', ...
    'XLim',[0 1],'YLim',[0 1]);
text(axEq,0.03,0.955,'GPS Positioning - Governing Equations', ...
    'FontSize',20,'FontWeight','bold','Interpreter','none');

% {caption, {latex lines}}
eq = {
 'Pseudorange equation', ...
   {'$\rho_i=\sqrt{(x_i-x_u)^2+(y_i-y_u)^2+(z_i-z_u)^2}\;+\;c\,\delta t_u+\varepsilon_i$'}
 'Satellite position (circular Keplerian orbit, ECI)', ...
   {'$n=\sqrt{\mu/a^{3}},\qquad u_k=M_{0,k}+n\,t$', ...
    '$\mathbf{s}_k=R_z(\Omega_k)\,R_x(i)\,[\,a\cos u_k,\;a\sin u_k,\;0\,]^{T}$'}
 'Linearisation about the current estimate', ...
   {'$\Delta\rho_i=\rho_i-(\hat r_i+\hat b)=\mathbf{h}_i\,\Delta\mathbf{x},\qquad \hat r_i=\left|\mathbf{s}_i-\hat{\mathbf{x}}\right|$', ...
    '$\mathbf{h}_i=\left[-\frac{x_i-\hat x}{\hat r_i},\;-\frac{y_i-\hat y}{\hat r_i},\;-\frac{z_i-\hat z}{\hat r_i},\;1\right]$'}
 'Least-squares position update (Gauss-Newton)', ...
   {'$\Delta\mathbf{x}=(H^{T}H)^{-1}H^{T}\,\Delta\rho,\qquad \hat{\mathbf{x}}\leftarrow\hat{\mathbf{x}}+\Delta\mathbf{x}$', ...
    '$\hat{\mathbf{x}}=[\hat x,\hat y,\hat z,\hat b]^{T},\qquad b=c\,\delta t_u$'}
 'Dilution of precision', ...
   {'$\mathrm{GDOP}=\sqrt{\mathrm{tr}\,[(H^{T}H)^{-1}]},\qquad \sigma_{pos}\approx \mathrm{PDOP}\cdot\sigma_{UERE}$'}
 'Satellite elevation (visibility mask)', ...
   {'$\sin(el_i)=\frac{(\mathbf{s}_i-\mathbf{u})\cdot\hat{\mathbf{u}}}{\left|\mathbf{s}_i-\mathbf{u}\right|}$'}
};
y = 0.885;
for k = 1:size(eq,1)
    text(axEq,0.03,y,[num2str(k) '.  ' eq{k,1}],'FontSize',13, ...
        'FontWeight','bold','Color',[0.1 0.3 0.6],'Interpreter','none');
    y = y - 0.05;
    for j = 1:numel(eq{k,2})
        text(axEq,0.06,y,eq{k,2}{j},'Interpreter','latex','FontSize',17);
        y = y - 0.058;
    end
    y = y - 0.012;
end
% Notation key (TeX interpreter, simpler markup)
text(axEq,0.70,0.80,{ ...
    '\bfNotation\rm', ...
    '\rho_i : measured pseudorange to satellite i', ...
    '(x_i,y_i,z_i) = s_i : satellite position', ...
    '(x_u,y_u,z_u) = u : true user position', ...
    'c : speed of light,  \deltat_u : receiver clock bias', ...
    '\epsilon_i : measurement noise', ...
    'H : geometry matrix (rows h_i)', ...
    '\mu : Earth gravitational parameter', ...
    'a, i, \Omega, M_0 : orbit radius, inclination,', ...
    '      RAAN, initial mean anomaly'}, ...
    'FontSize',12,'VerticalAlignment','top','Interpreter','tex', ...
    'BackgroundColor',[0.94 0.96 1],'EdgeColor',[0.7 0.8 0.95],'Margin',8);

%% =====================================================================
%  SECTION 5 - GUI DESIGN: "MATLAB Functions" tab (live source viewer)
%  =====================================================================
fnNames = {'satelliteECI','computePseudoranges','solvePositionLS', ...
           'computeDOP','elevationAngles','userTrajectory','stepSimulation'};
fnInfo  = {
 ['Implements the satellite position equation. Mean anomaly grows linearly with time, '...
  'the in-plane position (a cos u, a sin u, 0) is rotated by the inclination (Rx) and the '...
  'RAAN (Rz). The code is vectorised over all 24 satellites, so one call returns an N-by-3 matrix.']
 ['Implements the pseudorange equation. vecnorm gives the geometric range |s_i - u|; the '...
  'receiver clock bias b = c*dt_u (in km) and Gaussian noise (randn) are added to every range.']
 ['Implements the linearised least-squares solver. Each iteration builds H (unit line-of-sight '...
  'vectors plus a column of ones for the clock), forms the residual dRho, and solves '...
  'dx = H\dRho. MATLAB backslash solves the least-squares problem with QR, which is more '...
  'stable than inv(H''*H)*H''*dRho. Iterates until the position step is below 0.1 mm.']
 ['Implements GDOP = sqrt(trace(inv(H''*H))) and PDOP (position block only). Small values mean '...
  'good satellite geometry; position error is roughly PDOP times the range error.']
 ['Implements the elevation equation using the local vertical (u/|u|) and asind. Satellites '...
  'below the elevation mask are excluded from the pseudorange set and drawn grey.']
 ['Moves the user along a gently curving great-circle-like path. Speed and heading give '...
  'latitude/longitude rates; longitude is divided by cos(lat) so the ground distance is correct.']
 ['The nested simulation step called once per animation frame: advance time, move satellites '...
  'and user, determine visibility, generate pseudoranges, solve for position, update histories, '...
  'and refresh every graphics object and the status panel.']
};
uicontrol(tabFn,'Style','text','Units','normalized','Position',[0.02 0.94 0.4 0.04], ...
    'String','Functions (select one)','FontSize',12,'FontWeight','bold', ...
    'HorizontalAlignment','left','BackgroundColor',bg);
lbFn = uicontrol(tabFn,'Style','listbox','Units','normalized', ...
    'Position',[0.02 0.04 0.20 0.90],'String',fnNames,'FontSize',12, ...
    'Callback',@onSelectFunction);
txtFnInfo = uicontrol(tabFn,'Style','text','Units','normalized', ...
    'Position',[0.24 0.74 0.74 0.20],'FontSize',12,'HorizontalAlignment','left', ...
    'BackgroundColor','w');
edFnCode = uicontrol(tabFn,'Style','edit','Units','normalized', ...
    'Position',[0.24 0.04 0.74 0.69],'Max',200,'Min',0,'FontName','Courier New', ...
    'FontSize',11,'HorizontalAlignment','left','BackgroundColor',[0.98 0.98 0.94]);
onSelectFunction();   % populate with the first function

%% =====================================================================
%  SECTION 6 - GUI DESIGN: simulation tab controls
%  =====================================================================
pnl = uipanel(tabSim,'Units','normalized','Position',[0.005 0.01 0.19 0.98], ...
    'Title','Controls','FontSize',12,'BackgroundColor',bg);
btnRun   = uicontrol(pnl,'Style','pushbutton','Units','normalized', ...
    'Position',[0.05 0.93 0.42 0.045],'String','Start','FontSize',12, ...
    'FontWeight','bold','Callback',@onRun);
btnReset = uicontrol(pnl,'Style','pushbutton','Units','normalized', ...
    'Position',[0.53 0.93 0.42 0.045],'String','Reset','FontSize',12, ...
    'Callback',@onReset);
slDt    = addSlider(pnl,'Time step per frame [s]',0.84,10,600,120);
slNoise = addSlider(pnl,'Pseudorange noise sigma [m]',0.76,0,30,5);
slMask  = addSlider(pnl,'Elevation mask [deg]',0.68,0,40,10);
slSpeed = addSlider(pnl,'User speed [km/h]',0.60,0,1500,900);
chkLines = uicontrol(pnl,'Style','checkbox','Units','normalized', ...
    'Position',[0.05 0.54 0.9 0.03],'String','Show pseudorange lines', ...
    'Value',1,'BackgroundColor',bg,'FontSize',11);
chkOrbit = uicontrol(pnl,'Style','checkbox','Units','normalized', ...
    'Position',[0.05 0.50 0.9 0.03],'String','Show orbits', ...
    'Value',1,'BackgroundColor',bg,'FontSize',11, ...
    'Callback',@(s,~) set(hOrb,'Visible',onoff(s.Value)));
txtStatus = uicontrol(pnl,'Style','text','Units','normalized', ...
    'Position',[0.03 0.01 0.94 0.47],'FontName','Courier New','FontSize',10, ...
    'HorizontalAlignment','left','BackgroundColor','w');

%% =====================================================================
%  SECTION 7 - VISUALIZATION: create all graphics objects once
%  =====================================================================
% ---- 3D scene (ECI) ---------------------------------------------------
ax3 = axes('Parent',tabSim,'Position',[0.22 0.06 0.46 0.88]);
hold(ax3,'on'); axis(ax3,'equal'); grid(ax3,'on');
set(ax3,'Color',[0.03 0.03 0.10],'XColor',[.75 .75 .75],'YColor',[.75 .75 .75], ...
    'ZColor',[.75 .75 .75],'GridColor',[.6 .6 .6],'XLim',[-3e4 3e4], ...
    'YLim',[-3e4 3e4],'ZLim',[-3e4 3e4]);
xlabel(ax3,'X_{ECI} [km]'); ylabel(ax3,'Y_{ECI} [km]'); zlabel(ax3,'Z_{ECI} [km]');
view(ax3,[40 22]); rotate3d(ax3,'on');
[Xs,Ys,Zs] = sphere(36);
surf(ax3,C.Re*Xs,C.Re*Ys,C.Re*Zs,'FaceColor',[0.2 0.45 0.85], ...
    'EdgeColor',[0.6 0.7 1],'EdgeAlpha',0.25,'FaceAlpha',0.85);
uu = linspace(0,2*pi,240).';
hOrb = gobjects(nPlanes,1);
for p = 1:nPlanes                       % static orbit rings (ECI)
    ring = satelliteECI(struct('M0',uu,'raan',deg2rad(60*(p-1))*ones(size(uu)),'n',0), ...
                        C.a,C.inc,0);
    hOrb(p) = plot3(ax3,ring(:,1),ring(:,2),ring(:,3),'-','Color',[0.45 0.45 0.55]);
end
hLines  = plot3(ax3,nan,nan,nan,'-','Color',[1 0.65 0.1],'LineWidth',1);
hSatHid = plot3(ax3,nan,nan,nan,'o','LineStyle','none','MarkerSize',6, ...
    'MarkerFaceColor',[0.5 0.5 0.5],'MarkerEdgeColor',[0.8 0.8 0.8]);
hSatVis = plot3(ax3,nan,nan,nan,'o','LineStyle','none','MarkerSize',8, ...
    'MarkerFaceColor',[0.1 0.9 0.3],'MarkerEdgeColor','w');
hTrail  = plot3(ax3,nan,nan,nan,'-','Color',[0.3 1 0.4],'LineWidth',1.5);
hUser   = plot3(ax3,nan,nan,nan,'p','MarkerSize',15,'MarkerFaceColor',[1 1 0], ...
    'MarkerEdgeColor','k');
hEst    = plot3(ax3,nan,nan,nan,'x','MarkerSize',13,'LineWidth',2.2,'Color',[1 0.2 0.2]);
legend(ax3,[hSatVis hSatHid hLines hUser hEst], ...
    {'Visible satellite','Below mask','Pseudorange','True user','Estimated user'}, ...
    'TextColor','w','Color',[0.1 0.1 0.18],'Location','northwest');
title(ax3,'GPS constellation, pseudoranges and user','Color','k');

% ---- East/North error scatter -----------------------------------------
axENU = axes('Parent',tabSim,'Position',[0.745 0.60 0.235 0.32]);
hold(axENU,'on'); grid(axENU,'on'); axis(axENU,'equal');
hENU    = plot(axENU,nan,nan,'.','Color',[0.85 0.2 0.2],'MarkerSize',8);
hENUcur = plot(axENU,nan,nan,'ko','MarkerFaceColor','y','MarkerSize',8);
plot(axENU,0,0,'k+','MarkerSize',12);
xlabel(axENU,'East error [m]'); ylabel(axENU,'North error [m]');
title(axENU,'Horizontal position error (true = origin)');

% ---- Error and GDOP versus time ---------------------------------------
axTS = axes('Parent',tabSim,'Position',[0.745 0.09 0.235 0.40]);
grid(axTS,'on'); hold(axTS,'on');
yyaxis(axTS,'left');  hErr = plot(axTS,nan,nan,'-','LineWidth',1.4);
ylabel(axTS,'3D error [m]');
yyaxis(axTS,'right'); hGd  = plot(axTS,nan,nan,'-','LineWidth',1.4);
ylabel(axTS,'GDOP'); xlabel(axTS,'Time [min]');
title(axTS,'Position error and GDOP');

onReset();   % draw the initial frame (t = 0)

%% =====================================================================
%  SECTION 8 - CALLBACKS AND SIMULATION LOOP (nested functions)
%  =====================================================================
    function onSelectFunction(~,~)
        % Show explanation + live source code of the selected function.
        idx = lbFn.Value;
        set(txtFnInfo,'String',['  ' fnNames{idx} ' : ' fnInfo{idx}]);
        set(edFnCode,'String',getFunctionSource(fnNames{idx}));
    end

    function onRun(~,~)
        % Start/pause toggle; the while-loop IS the real-time animation.
        if running
            running = false; set(btnRun,'String','Start'); return;
        end
        running = true; set(btnRun,'String','Pause');
        while running && isvalid(fig)
            stepSimulation(round(get(slDt,'Value')));
            drawnow limitrate;
            pause(0.02);
        end
    end

    function onReset(~,~)
        running = false; set(btnRun,'String','Start');
        t = 0; lat = deg2rad(10); lon = deg2rad(106);
        xPrev = zeros(4,1); trail = zeros(0,3); enuHist = zeros(0,2);
        tHist = zeros(0,1); errHist = zeros(0,1); gdHist = zeros(0,1);
        stepSimulation(0);
    end

    function onClose(~,~)
        running = false; delete(fig);
    end

    function stepSimulation(dt)
        % ---- read live GUI parameters
        sigma = get(slNoise,'Value')/1000;     % m -> km
        mask  = get(slMask,'Value');           % deg
        vel   = get(slSpeed,'Value');          % km/h

        % ---- advance time, user and satellites
        t = t + dt;
        [lat,lon] = userTrajectory(lat,lon,t,vel,dt,C.Re);
        th   = C.we * t;                                   % Earth rotation angle
        lamI = lon + th;                                   % inertial longitude
        uVec = C.Re*[cos(lat)*cos(lamI); cos(lat)*sin(lamI); sin(lat)];
        S    = satelliteECI(cn,C.a,C.inc,t);               % nSat x 3

        % ---- visibility
        el  = elevationAngles(S,uVec);
        vis = el >= mask;
        nv  = nnz(vis);

        % ---- pseudoranges and position solution
        bTrue = C.c*(1e-4 + 2e-9*t);                       % true clock bias [km]
        gdop = NaN; pdop = NaN; errM = NaN; fix = false; enu = [NaN NaN];
        xhat = xPrev;
        if nv >= 4
            rho = computePseudoranges(S(vis,:),uVec,bTrue,sigma);
            [xhat,H] = solvePositionLS(S(vis,:),rho,xPrev);
            xPrev = xhat; fix = true;
            [gdop,pdop] = computeDOP(H);
            e = xhat(1:3) - uVec;                          % ECI error vector
            up = uVec/norm(uVec);
            east = cross([0;0;1],up); east = east/norm(east);
            north = cross(up,east);
            enu  = 1000*[dot(e,east) dot(e,north)];        % m
            errM = 1000*norm(e);
            % ---- histories (capped length)
            trail   = [trail; uVec.'];             %#ok<AGROW>
            enuHist = [enuHist; enu];              %#ok<AGROW>
            tHist   = [tHist; t];                  %#ok<AGROW>
            errHist = [errHist; errM];             %#ok<AGROW>
            gdHist  = [gdHist; gdop];              %#ok<AGROW>
            if size(trail,1) > 3000
                trail = trail(end-2999:end,:); enuHist = enuHist(end-2999:end,:);
                tHist = tHist(end-2999:end); errHist = errHist(end-2999:end);
                gdHist = gdHist(end-2999:end);
            end
        end

        % ---- refresh visualization
        Sv = S(vis,:);  Sh = S(~vis,:);
        set(hSatVis,'XData',Sv(:,1),'YData',Sv(:,2),'ZData',Sv(:,3));
        set(hSatHid,'XData',Sh(:,1),'YData',Sh(:,2),'ZData',Sh(:,3));
        if get(chkLines,'Value') && nv > 0                 % pseudorange lines u -> s_i
            XL = [uVec(1)*ones(nv,1) Sv(:,1) nan(nv,1)].';
            YL = [uVec(2)*ones(nv,1) Sv(:,2) nan(nv,1)].';
            ZL = [uVec(3)*ones(nv,1) Sv(:,3) nan(nv,1)].';
            set(hLines,'XData',XL(:),'YData',YL(:),'ZData',ZL(:));
        else
            set(hLines,'XData',nan,'YData',nan,'ZData',nan);
        end
        set(hUser,'XData',uVec(1),'YData',uVec(2),'ZData',uVec(3));
        if fix
            set(hEst,'XData',xhat(1),'YData',xhat(2),'ZData',xhat(3));
        end
        if ~isempty(trail)
            set(hTrail,'XData',trail(:,1),'YData',trail(:,2),'ZData',trail(:,3));
        else
            set(hTrail,'XData',nan,'YData',nan,'ZData',nan);
        end
        if ~isempty(enuHist)
            set(hENU,'XData',enuHist(:,1),'YData',enuHist(:,2));
            set(hENUcur,'XData',enuHist(end,1),'YData',enuHist(end,2));
            set(hErr,'XData',tHist/60,'YData',errHist);
            set(hGd, 'XData',tHist/60,'YData',gdHist);
        else
            set(hENU,'XData',nan,'YData',nan); set(hENUcur,'XData',nan,'YData',nan);
            set(hErr,'XData',nan,'YData',nan); set(hGd,'XData',nan,'YData',nan);
        end
        title(ax3,sprintf('t = %.2f h   |   visible satellites: %d / %d',t/3600,nv,nSat), ...
            'Color','k');

        % ---- status panel
        if fix
            lines = { ...
              sprintf('Time        : %8.1f min',t/60)
              sprintf('Satellites  : %d visible',nv)
              sprintf('Lat / Lon   : %6.2f / %6.2f deg',rad2deg(lat),rad2deg(lon))
              ''
              sprintf('True  x [km]: %9.3f',uVec(1))
              sprintf('True  y [km]: %9.3f',uVec(2))
              sprintf('True  z [km]: %9.3f',uVec(3))
              sprintf('Est.  x [km]: %9.3f',xhat(1))
              sprintf('Est.  y [km]: %9.3f',xhat(2))
              sprintf('Est.  z [km]: %9.3f',xhat(3))
              ''
              sprintf('Clock bias true: %8.3f km',bTrue)
              sprintf('Clock bias est : %8.3f km',xhat(4))
              sprintf('3D error  : %7.2f m',errM)
              sprintf('GDOP/PDOP : %5.2f / %5.2f',gdop,pdop)};
        else
            lines = {sprintf('Time: %.1f min',t/60), ...
                     sprintf('Only %d satellites visible', nv), ...
                     'Need >= 4 for a fix.'};
        end
        set(txtStatus,'String',lines);
    end

    function sl = addSlider(parent,labelTxt,yPos,lo,hi,val)
        % Helper: label + live value readout + slider.
        uicontrol(parent,'Style','text','Units','normalized', ...
            'Position',[0.05 yPos+0.035 0.62 0.028],'String',labelTxt, ...
            'HorizontalAlignment','left','BackgroundColor',bg,'FontSize',10);
        valLbl = uicontrol(parent,'Style','text','Units','normalized', ...
            'Position',[0.68 yPos+0.035 0.27 0.028],'String',sprintf('%.0f',val), ...
            'HorizontalAlignment','right','BackgroundColor',bg,'FontSize',10, ...
            'FontWeight','bold');
        sl = uicontrol(parent,'Style','slider','Units','normalized', ...
            'Position',[0.05 yPos 0.90 0.03],'Min',lo,'Max',hi,'Value',val, ...
            'Callback',@(s,~) set(valLbl,'String',sprintf('%.0f',s.Value)));
    end
end  % ===== end of main function gps_gui_simulator =====


%% =====================================================================
%  LOCAL FUNCTIONS - SIMULATION LOGIC (shown verbatim in the "Functions" tab)
%  =====================================================================
function S = satelliteECI(cn,a,inc,t)
% Circular Keplerian orbit -> ECI position of every satellite (N x 3, km).
u  = cn.M0 + cn.n*t;                      % argument of latitude u_k = M0 + n t
xo = a*cos(u);  yo = a*sin(u);            % in-plane coordinates
X  = xo.*cos(cn.raan) - yo.*cos(inc).*sin(cn.raan);   % Rz(RAAN)*Rx(inc)
Y  = xo.*sin(cn.raan) + yo.*cos(inc).*cos(cn.raan);
Z  = yo.*sin(inc);
S  = [X Y Z];
end

function rho = computePseudoranges(S,u,b,sigma)
% rho_i = |s_i - u| + b + noise      (b = c*dt_u in km, sigma in km)
r   = vecnorm(S - u(:).', 2, 2);          % geometric range, N x 1
rho = r + b + sigma*randn(size(r));
end

function [x,H] = solvePositionLS(S,rho,x0)
% Gauss-Newton least squares for x = [x y z b]^T from N >= 4 pseudoranges.
x = x0(:);
for iter = 1:15
    d    = S - x(1:3).';                  % vectors from estimate to satellites
    r    = vecnorm(d,2,2);                % predicted ranges
    H    = [-d./r, ones(size(r))];        % geometry matrix
    dRho = rho - (r + x(4));              % pseudorange residual
    dx   = H \ dRho;                      % least-squares step (QR)
    x    = x + dx;                        % state update
    if norm(dx(1:3)) < 1e-7, break; end   % converged (< 0.1 mm)
end
d = S - x(1:3).';  r = vecnorm(d,2,2);    % H at the final estimate (for DOP)
H = [-d./r, ones(size(r))];
end

function [gdop,pdop] = computeDOP(H)
% Dilution of precision from the geometry matrix.
if rcond(H.'*H) < 1e-12
    gdop = NaN; pdop = NaN; return;       % degenerate geometry
end
Q    = inv(H.'*H);
gdop = sqrt(trace(Q));
pdop = sqrt(trace(Q(1:3,1:3)));
end

function el = elevationAngles(S,u)
% Elevation [deg] of every satellite as seen from user position u (ECI).
up = u(:)/norm(u);                        % local vertical
d  = S - u(:).';
el = asind((d*up) ./ vecnorm(d,2,2));
end

function [lat,lon] = userTrajectory(lat,lon,t,vel,dt,Re)
% Aircraft-like motion on the Earth surface with slowly varying heading.
hdg = 0.6 + 0.8*sin(t/2400);              % heading from north [rad]
ds  = vel/3600*dt;                        % distance travelled [km]
lat = lat + ds*cos(hdg)/Re;
lon = lon + ds*sin(hdg)/(Re*cos(lat));
lat = max(min(lat,deg2rad(80)),deg2rad(-80));
end


%% =====================================================================
%  LOCAL HELPERS - GUI support
%  =====================================================================
function s = onoff(v)
% Convert a checkbox value into 'on'/'off'.
if v, s = 'on'; else, s = 'off'; end
end

function src = getFunctionSource(name)
% Read this very file and return the source lines of function <name>
% (works for both local functions and the nested stepSimulation).
f = [mfilename('fullpath') '.m'];
if ~isfile(f)
    src = {'Source file not found - run gps_gui_simulator from a saved .m file.'};
    return;
end
L  = regexp(fileread(f),'\r?\n','split');
L  = regexprep(L,'\s+$','');
i0 = find(~cellfun(@isempty,regexp(L,['^\s*function\s+.*\<' name '\s*\('],'once')),1);
if isempty(i0), src = {['Function ' name ' not found.']}; return; end
ind = regexp(L{i0},'^\s*','match','once');
i1  = i0 + find(strcmp(L(i0+1:end),[ind 'end']),1);
src = L(i0:i1);
end
