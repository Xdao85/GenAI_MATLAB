% finite_wire_B.m
% Magnetic flux density of a finite straight wire (undergraduate EM course)
% - Closed-form finite-wire formula vs. numerical Biot-Savart integration
% - Base MATLAB only. Local functions at the end of the file require
%   MATLAB R2016b or newer (script files with local functions).
% Units: SI (m, A, T)

clear; clc; close all;

%% ---------------- Problem data ----------------
mu0 = 4*pi*1e-7;          % permeability of free space (H/m)
I   = 1;                  % current (A), flowing in +z
A   = [0.25, 0.5, 0];     % wire center / axis point (m)
z1  = -1;                 % wire start, z coordinate (m)
z2  =  1;                 % wire end,   z coordinate (m), length = 2 m
P   = [1, 1, 0];          % observation point (m)
tol = 1e-3;               % allowed relative vector error (0.1 %)

%% ---------------- Solutions ----------------
B_ref = B_closed_form(mu0, I, A, z1, z2, P);        % closed form (T)
B_num = B_biot_savart_numeric(mu0, I, A, z1, z2, P); % numerical (T)

%% ---------------- Comparison ----------------
rel_err = norm(B_num - B_ref) / norm(B_ref);   % relative vector error

fprintf('B closed form  = [%12.6e %12.6e %12.6e] T\n', B_ref);
fprintf('B numerical    = [%12.6e %12.6e %12.6e] T\n', B_num);
fprintf('|B| closed form = %12.6e T\n', norm(B_ref));
fprintf('Relative vector error = %.3e (limit %.1e)\n', rel_err, tol);

%% ---------------- Right-hand rule check ----------------
% Thumb along +z (current). Fingers curl counterclockwise seen from +z, so
% B at P must point along z_hat x rho_hat, where rho_hat points from the
% wire axis to P. B must also have no z component and be perpendicular to rho.
zhat    = [0, 0, 1];                         % current direction
rho_vec = [P(1)-A(1), P(2)-A(2), 0];         % axis-to-P perpendicular vector (m)
rho_hat = rho_vec / norm(rho_vec);           % unit radial vector
phi_hat = cross(zhat, rho_hat);              % azimuthal unit vector (RHR)

along_phi  = dot(B_num, phi_hat) / norm(B_num);  % should be +1
along_rho  = dot(B_num, rho_hat) / norm(B_num);  % should be 0
along_z    = dot(B_num, zhat)    / norm(B_num);  % should be 0
rhr_ok = (along_phi > 1 - 1e-6) && (abs(along_rho) < 1e-6) && (abs(along_z) < 1e-6);

fprintf('Right-hand rule: cos(B,phi_hat) = %+.6f, cos(B,rho_hat) = %+.2e, cos(B,z_hat) = %+.2e -> ', ...
        along_phi, along_rho, along_z);
if rhr_ok
    fprintf('OK\n');
else
    fprintf('FAILED\n');
end

%% ---------------- Stop conditions ----------------
if rel_err > tol
    error('finite_wire_B:accuracy', ...
          'Stopped: relative vector error %.3e exceeds 0.1 %% (%.1e).', rel_err, tol);
end
if ~rhr_ok
    error('finite_wire_B:rhr', ...
          'Stopped: B direction violates the right-hand rule.');
end
fprintf('All checks passed.\n');

%% ---------------- Plot ----------------
plot_geometry(A, z1, z2, P, B_ref);

%% =====================================================================
%% Local functions
%% =====================================================================

function B = B_closed_form(mu0, I, A, z1, z2, P)
% Closed-form field of a finite straight wire along z through (A(1),A(2)).
    % Perpendicular distance from wire axis to P (m)
    rho_vec = [P(1)-A(1), P(2)-A(2), 0];
    rho     = norm(rho_vec);

    % Axial coordinates of the wire ends relative to P's z (m)
    za = z1 - P(3);                 % lower end relative to P
    zb = z2 - P(3);                 % upper end relative to P

    % Sines of the angles subtended by the ends, sin(alpha) = z/sqrt(rho^2+z^2)
    sin_a1 = za / sqrt(rho^2 + za^2);
    sin_a2 = zb / sqrt(rho^2 + zb^2);

    % Magnitude: B = mu0*I/(4*pi*rho) * (sin(alpha2) - sin(alpha1))   (T)
    Bmag = mu0 * I / (4*pi*rho) * (sin_a2 - sin_a1);

    % Direction: azimuthal unit vector, phi_hat = z_hat x rho_hat
    phi_hat = cross([0, 0, 1], rho_vec / rho);

    % Vector result (T)
    B = Bmag * phi_hat;
end

function B = B_biot_savart_numeric(mu0, I, A, z1, z2, P)
% Numerical Biot-Savart: B = mu0*I/(4*pi) * integral( dl x R / |R|^3 )
    % Source point on the wire at parameter zp (m): r' = (A(1), A(2), zp)
    % Separation vector from source to field point: R = P - r'   (m)
    % Current element: dl = z_hat * dzp                           (m)
    % Integrand: (z_hat x R) / |R|^3                              (1/m^2 * m)
    integrand = @(zp) cross([0; 0; 1], (P(:) - [A(1); A(2); zp])) ...
                      ./ norm(P(:) - [A(1); A(2); zp])^3;

    % Integrate along the wire from z1 to z2 (vector-valued integrand)
    S = integral(integrand, z1, z2, 'ArrayValued', true, ...
                 'RelTol', 1e-10, 'AbsTol', 1e-16);

    % Multiply by mu0*I/(4*pi) and return a row vector (T)
    B = (mu0 * I / (4*pi) * S).';
end

function plot_geometry(A, z1, z2, P, B)
% Plot wire, center point A, observation point P and the B vector.
    figure('Name', 'Finite wire and B at P');
    hold on; grid on;

    % Wire: straight line along z through (A(1), A(2)) (m)
    hw = plot3([A(1) A(1)], [A(2) A(2)], [z1 z2], 'b-', 'LineWidth', 3);

    % Point A (wire center) and observation point P
    hA = plot3(A(1), A(2), A(3), 'ko', 'MarkerFaceColor', 'k', 'MarkerSize', 7);
    hP = plot3(P(1), P(2), P(3), 'rs', 'MarkerFaceColor', 'r', 'MarkerSize', 8);

    % Current direction arrow (+z) drawn near the top of the wire (m)
    hI = quiver3(A(1), A(2), z2 - 0.5, 0, 0, 0.4, 0, 'b', 'LineWidth', 2, ...
                 'MaxHeadSize', 2);

    % B arrow: scaled to 0.5 m for visibility (true |B| is ~1e-7 T)
    Bscale = 0.5 / norm(B);                       % m per tesla (display only)
    hB = quiver3(P(1), P(2), P(3), Bscale*B(1), Bscale*B(2), Bscale*B(3), ...
                 0, 'r', 'LineWidth', 2, 'MaxHeadSize', 1.5);

    % Axis-to-P perpendicular segment (dashed) for reference
    plot3([A(1) P(1)], [A(2) P(2)], [0 0], 'k--');

    xlabel('x (m)'); ylabel('y (m)'); zlabel('z (m)');
    title(sprintf('Finite wire, B at P (arrow scaled; |B| = %.3e T)', norm(B)));
    legend([hw hA hP hI hB], {'Wire (2 m)', 'A (wire center)', 'P (observation)', ...
           'I direction (+z)', 'B at P (scaled)'}, 'Location', 'best');
    axis equal;
    view(3);
    hold off;
end
