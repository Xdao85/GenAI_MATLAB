%% ========================================================================
%  ELECTRIC FIELD OF TWO POINT CHARGES AT A POINT P (3D)
%  ------------------------------------------------------------------------
%  Mathematical formulation (Coulomb's law, superposition principle):
%
%    The field at P due to a single point charge q located at r_q is
%
%        E = k * q * (P - r_q) / |P - r_q|^3 ,   k = 1/(4*pi*eps0)
%
%    where (P - r_q) points from the charge to the field point, and
%    dividing by |P - r_q|^3 = (unit vector) / (distance^2).
%
%    For several charges, the fields add vectorially:
%
%        E_total = E_1 + E_2
%
%  NOTE: This file is a script with local functions (they must stay at the
%  END of the file). Requires MATLAB R2016b or newer.
%  ========================================================================
clear; clc; close all;

%% ------------------------- MAIN SCRIPT ----------------------------------

% ---- 1. Inputs (SI units: charges in Coulombs, positions in meters) -----
q1  = 2e-9;            % Charge 1 magnitude [C]  (+2 nC)
r1  = [-1, 0, 0];    % Charge 1 position [x y z] [m]

q2  = -2e-9;           % Charge 2 magnitude [C]  (-3 nC)
r2  = [1, 0, 0];    % Charge 2 position [x y z] [m]

P   = [0, 1, 2];    % Field point P = [Px Py Pz] [m]

% Pack charges into arrays so the field function works for any number of
% charges: row i of 'positions' belongs to charges(i).
charges   = [q1; q2];          % N-by-1 vector of charge magnitudes
positions = [r1; r2];          % N-by-3 matrix of charge positions

% ---- 2. Compute the electric field at P --------------------------------
E = computeElectricField(charges, positions, P);

% ---- 3. Report results in the command window ---------------------------
fprintf('Electric field at P = (%.2f, %.2f, %.2f) m:\n', P);
fprintf('  E = [%.4e, %.4e, %.4e] N/C\n', E);
fprintf('  |E| = %.4e N/C\n', norm(E));

% ---- 4. Visualize ------------------------------------------------------
plotElectricField(charges, positions, P, E);


%% ------------------------- LOCAL FUNCTIONS ------------------------------

function E = computeElectricField(charges, positions, P)
% COMPUTEELECTRICFIELD  Net electric field at P from point charges.
%
%   E = computeElectricField(charges, positions, P)
%
%   Inputs:
%     charges   - N-by-1 vector of charge magnitudes [C] (sign matters)
%     positions - N-by-3 matrix, each row is [x y z] of a charge [m]
%     P         - 1-by-3 field point [Px Py Pz] [m]
%
%   Output:
%     E         - 1-by-3 net electric field vector [Ex Ey Ez] [N/C]

    % Physical constants
    eps0 = 8.8541878128e-12;       % Vacuum permittivity [F/m]
    k    = 1 / (4*pi*eps0);        % Coulomb constant [N*m^2/C^2]

    P = P(:).';                    % Force P to be a 1-by-3 row vector
    E = zeros(1, 3);               % Accumulator for the net field

    for i = 1:numel(charges)
        % Displacement vector from charge i to the field point
        R    = P - positions(i, :);
        dist = norm(R);            % Distance |P - r_i|

        % Guard against evaluating the field exactly at a charge,
        % where Coulomb's law is singular.
        if dist == 0
            error('Field point P coincides with charge %d; E is undefined.', i);
        end

        % Coulomb's law for charge i, then superposition (sum)
        E = E + k * charges(i) * R / dist^3;
    end
end


function plotElectricField(charges, positions, P, E)
% PLOTELECTRICFIELD  3D visualization of the charges and the field at P.
%
%   Draws each charge as a colored marker (red = positive, blue =
%   negative), the field point P, and the field vector E at P using quiver3.
%   The arrow is rescaled for display only (its direction is exact).

    figure('Name', 'Electric Field of Two Point Charges', 'Color', 'w');
    hold on; grid on; box on;

    % ---- Plot the charges ----
    for i = 1:numel(charges)
        if charges(i) >= 0, c = 'r'; else, c = 'b'; end
        plot3(positions(i,1), positions(i,2), positions(i,3), 'o', ...
              'MarkerSize', 12, 'MarkerFaceColor', c, 'MarkerEdgeColor', 'k');
        text(positions(i,1), positions(i,2), positions(i,3), ...
             sprintf('  q_%d = %.2g nC', i, charges(i)*1e9), 'FontSize', 10);
    end

    % ---- Plot the field point ----
    plot3(P(1), P(2), P(3), 'ko', 'MarkerFaceColor', 'k', 'MarkerSize', 7);
    text(P(1), P(2), P(3), '  P', 'FontSize', 11, 'FontWeight', 'bold');

    % ---- Scale the arrow so it is visible regardless of E's magnitude ----
    % Make the arrow length ~ 40% of the distance scale of the scene.
    allPts   = [positions; P(:).'];
    sceneLen = max(max(allPts) - min(allPts));        % Characteristic size
    scale    = 0.4 * sceneLen / norm(E);              % Display scale factor
    Es       = E * scale;                             % Scaled vector

    % ---- Draw the field vector at P (the 3D quiver plot) ----
    % quiver3(x, y, z, u, v, w, 0): the 0 disables MATLAB's auto-scaling.
    quiver3(P(1), P(2), P(3), Es(1), Es(2), Es(3), 0, ...
            'Color', [0.1 0.6 0.1], 'LineWidth', 2.5, 'MaxHeadSize', 0.8);

    % ---- Labels, view and formatting ----
    xlabel('x [m]'); ylabel('y [m]'); zlabel('z [m]');
    title(sprintf('E at P: |E| = %.3e N/C (arrow length scaled for display)', norm(E)));
    legend({'Charge', 'Charge', 'Point P', 'E at P'}, 'Location', 'best');
    axis equal; view(3);
    hold off;
end
