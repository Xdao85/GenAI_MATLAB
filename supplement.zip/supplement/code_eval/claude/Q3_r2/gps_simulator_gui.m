function gps_simulator_gui()
% GPS_SIMULATOR_GUI  Interactive GPS dynamics simulator (MATLAB R2017b+).
%
%   Run:  >> gps_simulator_gui
%
%   Tabs:
%     1. Simulation : 3-D animation of a 24-satellite constellation, pseudorange
%                     lines, user motion, least-squares fix, DOP and error plots.
%     2. Equations  : GPS equations rendered with the LaTeX interpreter.
%     3. MATLAB Code: the MATLAB functions behind each equation, explained.
%
%   Model simplifications: spherical Earth, circular orbits (Walker 24/6/1,
%   55 deg), constant simple iono delay, user walking on a 100 m circle.

%% =====================================================================
%  SECTION 1 - PARAMETERS AND CONSTELLATION (simulation logic)
%  =====================================================================
P.c    = 299792458;          % speed of light [m/s]
P.mu   = 3.986004418e14;     % Earth gravitational parameter [m^3/s^2]
P.we   = 7.2921151467e-5;    % Earth rotation rate [rad/s]
P.Re   = 6371e3;             % mean Earth radius [m]
P.a    = 26560e3;            % GPS orbit semi-major axis [m]
P.inc  = deg2rad(55);        % orbital inclination
P.nSat = 24;

% Walker 24/6/1 layout: 6 planes x 4 satellites, phasing factor F = 1
[pp, kk] = meshgrid(0:5, 0:3);
P.raan = 2*pi*pp(:)'/6;                       % right ascension of each plane
P.M0   = 2*pi*kk(:)'/4 + 2*pi*1*pp(:)'/24;    % initial argument of latitude

% User: walks on a circle (radius Rpath, period Tpath) in a local ENU frame
P.lat0 = deg2rad(35);  P.lon0 = deg2rad(10);
P.Rpath = 100;  P.Tpath = 600;
P.clk0 = 8.5e-5;  P.clkDrift = 1e-9;          % receiver clock bias [s], drift [s/s]

% ENU basis vectors expressed in ECEF at the user's reference point
sp = sin(P.lat0); cp = cos(P.lat0); sl = sin(P.lon0); cl = cos(P.lon0);
P.e = [-sl; cl; 0];
P.n = [-sp*cl; -sp*sl; cp];
P.u = [ cp*cl;  cp*sl; sp];
P.Renu = [P.e'; P.n'; P.u'];                  % ECEF -> ENU rotation
P.p0 = P.Re*P.u;                              % reference point (ECEF)

% Run-time state (shared with the nested callbacks below)
t = 0;  running = false;  xhat = zeros(4,1);
trailN = 80;                                  % satellite trail length
push = @(v,x) [v(max(1,end-498):end) x];      % rolling history buffer
hist = struct('t',[],'err',[],'E',[],'N',[]);
TR = nan(trailN, P.nSat, 3);

%% =====================================================================
%  SECTION 2 - GUI DESIGN (figure, tabs, controls)
%  =====================================================================
fig = figure('Name','GPS Dynamics Simulator','NumberTitle','off', ...
    'Position',[40 40 1380 800],'Color','w','CloseRequestFcn',@onClose);
tg = uitabgroup(fig,'Position',[0 0 1 1]);
tab1 = uitab(tg,'Title','Simulation');
tab2 = uitab(tg,'Title','Equations (LaTeX)');
tab3 = uitab(tg,'Title','MATLAB Code');

% ---- Simulation tab: axes -------------------------------------------
ax3d  = axes('Parent',tab1,'Position',[0.04 0.06 0.50 0.88]);
axENU = axes('Parent',tab1,'Position',[0.63 0.66 0.34 0.29]);
axErr = axes('Parent',tab1,'Position',[0.63 0.40 0.34 0.18]);

% ---- Simulation tab: read-out text and control panel ------------------
readout = uicontrol(tab1,'Style','text','Units','normalized', ...
    'Position',[0.57 0.265 0.42 0.10],'FontName','Courier New', ...
    'FontSize',10,'HorizontalAlignment','left','BackgroundColor',[.96 .96 .96]);
pnl = uipanel(tab1,'Title','Controls','Position',[0.57 0.01 0.42 0.25]);
bg  = get(pnl,'BackgroundColor');

[slScale, ~] = mkSlider(pnl,0.80,'Time scale (x)',  [1 300], 60, '%.0f');
[slNoise, ~] = mkSlider(pnl,0.62,'Noise sigma (m)', [0 30],   5, '%.1f');
[slMask,  ~] = mkSlider(pnl,0.44,'Elev. mask (deg)',[0 40],  10, '%.0f');
chkIono = uicontrol(pnl,'Style','checkbox','Units','normalized', ...
    'Position',[0.02 0.26 0.60 0.12],'String','Add ionospheric delay (uncorrected)', ...
    'Value',1,'BackgroundColor',bg);
btnRun = uicontrol(pnl,'Style','pushbutton','Units','normalized', ...
    'Position',[0.05 0.04 0.40 0.17],'String','Start','FontWeight','bold', ...
    'Callback',@onStartPause);
uicontrol(pnl,'Style','pushbutton','Units','normalized', ...
    'Position',[0.55 0.04 0.40 0.17],'String','Reset','Callback',@onReset);

%% =====================================================================
%  SECTION 3 - LaTeX INTEGRATION (Equations tab)
%  Text objects with 'Interpreter','latex' typeset the formulas.
%  =====================================================================
axEq = axes('Parent',tab2,'Position',[0 0 1 1],'Visible','off', ...
            'XLim',[0 1],'YLim',[0 1]);
eqList = {
 '1. Pseudorange measurement', {
   '$\rho_i = \sqrt{(x_i-x_u)^2+(y_i-y_u)^2+(z_i-z_u)^2} + c\,\delta t_u + I_i + \varepsilon_i$'}
 '2. Geometric range and clock bias term', {
   '$r_i = \left| \mathbf{s}_i - \mathbf{x}_u \right| ,\quad b = c\,\delta t_u$'}
 '3. Linearisation about the estimate (Taylor, first order)', {
   '$\Delta\rho_i = \rho_i-(\hat{r}_i+\hat{b}) \approx -\mathbf{a}_i^{T}\,\Delta\mathbf{x}_u + \Delta b ,\quad \mathbf{a}_i=\frac{\mathbf{s}_i-\hat{\mathbf{x}}_u}{\hat{r}_i}$'}
 '4. Matrix form (n >= 4 satellites)', {
   '$\Delta\vec{\rho} = G\,\Delta\vec{x} ,\quad G=\left[\,-\mathbf{a}_i^{T}\ ,\ 1\,\right]_{n\times 4},\quad \vec{x}=[x_u,y_u,z_u,b]^{T}$'}
 '5. Least-squares position solution (Gauss-Newton iteration)', {
   '$\Delta\vec{x} = \left(G^{T}G\right)^{-1}G^{T}\,\Delta\vec{\rho} ,\quad \hat{x}_{k+1}=\hat{x}_{k}+\Delta\vec{x}$'}
 '6. Dilution of precision', {
   '$Q=\left(G^{T}G\right)^{-1},\quad \mathrm{PDOP}=\sqrt{Q_{11}+Q_{22}+Q_{33}},\quad \sigma_{3D}\approx \mathrm{PDOP}\cdot\sigma_{UERE}$'}
 '7. Satellite orbit (circular) and Earth rotation', {
   '$n=\sqrt{\mu/a^{3}},\quad u_k = M_k + n\,t$'
   '$x = a(\cos\Omega\cos u-\sin\Omega\cos i\,\sin u),\ \ y = a(\sin\Omega\cos u+\cos\Omega\cos i\,\sin u),\ \ z=a\sin i\,\sin u$'
   '$\mathbf{s}^{ECEF} = R_z(-\omega_e t)\,\mathbf{s}^{ECI}$'}
 '8. Satellite elevation (visibility test)', {
   '$El_i = \arcsin\left(\hat{\mathbf{u}}\cdot\mathbf{a}_i\right) \geq El_{mask}$'}
};
yy = 0.97;
for k = 1:size(eqList,1)
    text(axEq,0.02,yy,eqList{k,1},'FontWeight','bold','FontSize',12, ...
         'Color',[.1 .2 .5],'Interpreter','none','VerticalAlignment','top');
    yy = yy - 0.035;
    for m = 1:numel(eqList{k,2})
        text(axEq,0.04,yy,eqList{k,2}{m},'Interpreter','latex', ...
             'FontSize',15,'VerticalAlignment','top');
        yy = yy - 0.052;
    end
    yy = yy - 0.012;
end

%% =====================================================================
%  SECTION 4 - MATLAB FUNCTION EXPLANATIONS (Code tab)
%  =====================================================================
docs = {
 'vecnorm / norm  (Eq. 1-2)', {
  'Geometric range r_i = |s_i - x_u| for all satellites at once:'
  ''
  '    d   = satV - x(1:3);     % 3 x n vectors user -> satellite'
  '    r   = vecnorm(d);        % 1 x n Euclidean lengths'
  ''
  'vecnorm works column-wise, so one call replaces a loop over satellites.'
  'norm(dx(1:3)) is used for the convergence test of the solver.'}
 'randn  (Eq. 1, error term)', {
  'Zero-mean Gaussian measurement noise eps_i with std sigma:'
  ''
  '    rho = rng(vis) + b + I(vis) + sigma*randn(1,nv);'
  ''
  'The pseudorange = true range + receiver clock term + iono delay + noise.'}
 'asin, dot-product  (Eq. 8)', {
  'Elevation angle from the user "up" vector and line of sight:'
  ''
  '    los = sat - ru;'
  '    el  = asin( (P.u''*los) ./ vecnorm(los) );'
  '    vis = rad2deg(el) >= mask;'
  ''
  'P.u''*los is the dot product for every satellite; asin gives sin(El)^-1.'}
 'mldivide  \  (Eq. 5)', {
  'Normal equations solved with the backslash operator:'
  ''
  '    dx = (G''*G) \ (G''*dRho);'
  ''
  'Preferred over inv(G''*G)*G''*dRho: faster and numerically better.'
  'Each iteration x = x + dx moves the estimate closer to the solution'
  '(Gauss-Newton); 4-6 iterations are normally enough.'}
 'inv  (Eq. 6, DOP)', {
  'Covariance shape matrix of the position solution:'
  ''
  '    Q    = inv(G''*G);'
  '    PDOP = sqrt(trace(Q(1:3,1:3)));'
  ''
  'Here the explicit inverse is needed because DOP uses its diagonal.'
  'Rotating Q(1:3,1:3) with P.Renu yields HDOP and VDOP in East/North/Up.'}
 'sin, cos  (Eq. 7)', {
  'Circular orbit and ECI -> ECEF conversion in satPositions():'
  ''
  '    u  = P.M0 + sqrt(P.mu/P.a^3)*t;'
  '    x  = P.a*(cO.*cos(u) - sO.*ci.*sin(u));'
  '    ...'
  '    s  = [cos(th)*x+sin(th)*y; -sin(th)*x+cos(th)*y; z];'
  ''
  'th = we*t rotates the inertial frame into the rotating Earth frame.'}
 'text(...,''Interpreter'',''latex'')', {
  'Typesets the formulas on the Equations tab:'
  ''
  '    text(ax,x,y,''$\rho_i=\sqrt{...}$'',''Interpreter'',''latex'');'
  ''
  'Wrap the formula in $...$. Not every LaTeX package is available:'
  'MATLAB supports a core subset (\frac, \sqrt, \hat, \mathbf, ...).'}
 'set + drawnow limitrate  (animation)', {
  'Real-time update without re-creating graphics objects:'
  ''
  '    set(h.rng(k),''XData'',[ru(1) s(1,k)]/1e3, ...);'
  '    drawnow limitrate;'
  ''
  'Changing XData/YData/ZData of existing lines is far faster than calling'
  'plot3 every frame; "limitrate" caps the refresh and keeps buttons responsive.'}
 'Local functions in this file', {
  'satPositions(P,t)      -> 3 x N ECEF satellite positions.'
  'solvePosition(S,rho,x0)-> [x,G,iterations]; Gauss-Newton LS fix.'
  'computeDOP(G,Renu)     -> GDOP, PDOP, HDOP, VDOP.'
  'walker/userTruth       -> constellation and true user trajectory.'}
};
lb = uicontrol(tab3,'Style','listbox','Units','normalized', ...
    'Position',[0.01 0.02 0.25 0.96],'String',docs(:,1),'FontSize',11, ...
    'Callback',@onDocSelect);
edDoc = uicontrol(tab3,'Style','edit','Units','normalized','Max',2, ...
    'Enable','inactive','Position',[0.27 0.02 0.72 0.96],'BackgroundColor','w', ...
    'FontName','Courier New','FontSize',12,'HorizontalAlignment','left', ...
    'String',docs{1,2});

%% =====================================================================
%  SECTION 5 - VISUALIZATION SETUP (3-D scene, ENU plot, error plot)
%  =====================================================================
% ---- 3-D scene: Earth, satellites, trails, pseudorange lines ----------
hold(ax3d,'on'); grid(ax3d,'on'); view(ax3d,135,25);
[X,Y,Z] = sphere(36);
surf(ax3d,P.Re/1e3*X,P.Re/1e3*Y,P.Re/1e3*Z,'FaceColor',[.3 .5 .85], ...
     'FaceAlpha',.55,'EdgeColor',[.6 .7 .9],'EdgeAlpha',.35);
axis(ax3d,'equal'); lim = 3.2e4;
set(ax3d,'XLim',[-lim lim],'YLim',[-lim lim],'ZLim',[-lim lim]);
xlabel(ax3d,'X ECEF [km]'); ylabel(ax3d,'Y ECEF [km]'); zlabel(ax3d,'Z ECEF [km]');
rotate3d(ax3d,'on');

h.trail = gobjects(P.nSat,1);  h.rng = gobjects(P.nSat,1);
for k = 1:P.nSat
    h.trail(k) = plot3(ax3d,nan,nan,nan,'-','Color',[.75 .75 .75]);
    h.rng(k)   = plot3(ax3d,nan,nan,nan,'-','Color',[0 .65 .25],'LineWidth',1);
end
h.satVis = plot3(ax3d,nan,nan,nan,'o','MarkerFaceColor',[0 .65 .25], ...
                 'MarkerEdgeColor','k','MarkerSize',8);
h.satHid = plot3(ax3d,nan,nan,nan,'o','MarkerFaceColor',[.7 .7 .7], ...
                 'MarkerEdgeColor','k','MarkerSize',6);
h.user   = plot3(ax3d,nan,nan,nan,'p','MarkerFaceColor','r', ...
                 'MarkerEdgeColor','k','MarkerSize',14);
legend(ax3d,[h.satVis h.satHid h.user],{'Visible satellite','Below mask','User'}, ...
       'Location','northeast');

% ---- Local ENU plot: true path vs estimated positions -----------------
hold(axENU,'on'); grid(axENU,'on'); axis(axENU,'equal');
a_ = linspace(0,2*pi,200);
plot(axENU,P.Rpath*cos(a_),P.Rpath*sin(a_),'-','Color',[.6 .6 .6]);
h.estTrail = plot(axENU,nan,nan,'.','Color',[.1 .4 .9]);
h.enuTrue  = plot(axENU,nan,nan,'o','MarkerFaceColor','r','MarkerEdgeColor','k','MarkerSize',9);
h.enuEst   = plot(axENU,nan,nan,'s','MarkerFaceColor',[.1 .4 .9],'MarkerEdgeColor','k','MarkerSize',8);
set(axENU,'XLim',[-200 200],'YLim',[-200 200]);
xlabel(axENU,'East [m]'); ylabel(axENU,'North [m]');
title(axENU,'Local ENU: true path (red) vs GPS fixes (blue)');

% ---- Position-error history -------------------------------------------
hold(axErr,'on'); grid(axErr,'on');
h.err = plot(axErr,nan,nan,'-','Color',[.85 .3 .1],'LineWidth',1.2);
xlabel(axErr,'Simulation time [s]'); ylabel(axErr,'3-D error [m]');
title(axErr,'Position error');

stepSim(0);   % draw the initial frame

%% =====================================================================
%  SECTION 6 - CALLBACKS AND SIMULATION LOOP (simulation logic)
%  =====================================================================
    function onStartPause(~,~)
        % Start/pause toggle. The loop runs inside the callback; drawnow
        % lets the Pause/Reset buttons and sliders interrupt it.
        if running
            running = false;  set(btnRun,'String','Start');  return
        end
        running = true;  set(btnRun,'String','Pause');
        tPrev = tic;
        while running && isvalid(fig)
            dtReal = min(toc(tPrev),0.1);  tPrev = tic;
            stepSim(dtReal*get(slScale,'Value'));   % simulated seconds
            drawnow limitrate;
            pause(0.01);
        end
    end

    function onReset(~,~)
        running = false;  set(btnRun,'String','Start');
        t = 0;  xhat = zeros(4,1);  TR(:) = nan;
        hist = struct('t',[],'err',[],'E',[],'N',[]);
        stepSim(0);
    end

    function onClose(~,~)
        running = false;  delete(fig);     % stops the loop, closes window
    end

    function onDocSelect(src,~)
        set(edDoc,'String',docs{get(src,'Value'),2});
    end

    function stepSim(dt)
        % ---- advance time and read UI settings ----
        t = t + dt;
        sigma = get(slNoise,'Value');  mask = get(slMask,'Value');
        useIono = get(chkIono,'Value');

        % ---- true satellite and user positions (ECEF) ----
        sat = satPositions(P,t);
        ang = 2*pi*t/P.Tpath;
        E = P.Rpath*cos(ang);  Nn = P.Rpath*sin(ang);
        ru = P.p0 + E*P.e + Nn*P.n;

        % ---- visibility from elevation angle (Eq. 8) ----
        los = sat - ru;  rng = vecnorm(los);
        el  = asin((P.u'*los)./rng);
        vis = rad2deg(el) >= mask;  nv = nnz(vis);

        % ---- pseudorange generation (Eq. 1) ----
        b = P.c*(P.clk0 + P.clkDrift*t);                  % clock bias [m]
        I = zeros(1,P.nSat);
        if useIono, I = 5*(1 + 16*(0.53 - el/pi).^3); end % simple iono model [m]
        rho = rng(vis) + b + I(vis) + sigma*randn(1,nv);

        % ---- least-squares fix and DOP (Eq. 3-6) ----
        fix = nv >= 4;
        if fix
            [xhat,G,it] = solvePosition(sat(:,vis),rho,xhat);
            dop = computeDOP(G,P.Renu);
            enu = P.Renu*(xhat(1:3) - P.p0);          % estimate in ENU about p0
            err = norm(xhat(1:3) - ru);
            hist.t = push(hist.t,t);   hist.err = push(hist.err,err);
            hist.E = push(hist.E,enu(1));  hist.N = push(hist.N,enu(2));
        end

        % ---- satellite trails (ring buffer) ----
        TR = [TR(2:end,:,:); reshape(sat'/1e3,1,P.nSat,3)];

        % ---- 3-D graphics update ----
        set(h.satVis,'XData',sat(1,vis)/1e3,'YData',sat(2,vis)/1e3,'ZData',sat(3,vis)/1e3);
        set(h.satHid,'XData',sat(1,~vis)/1e3,'YData',sat(2,~vis)/1e3,'ZData',sat(3,~vis)/1e3);
        set(h.user,'XData',ru(1)/1e3,'YData',ru(2)/1e3,'ZData',ru(3)/1e3);
        for k = 1:P.nSat
            set(h.trail(k),'XData',TR(:,k,1),'YData',TR(:,k,2),'ZData',TR(:,k,3));
            if vis(k)   % pseudorange line user -> satellite
                set(h.rng(k),'XData',[ru(1) sat(1,k)]/1e3,'YData',[ru(2) sat(2,k)]/1e3, ...
                    'ZData',[ru(3) sat(3,k)]/1e3,'Visible','on');
            else
                set(h.rng(k),'Visible','off');
            end
        end
        title(ax3d,sprintf('Constellation (ECEF)   t = %.0f s',t));

        % ---- ENU / error plots and read-out ----
        set(h.enuTrue,'XData',E,'YData',Nn);
        if fix
            set(h.estTrail,'XData',hist.E,'YData',hist.N);
            set(h.enuEst,'XData',enu(1),'YData',enu(2));
            set(h.err,'XData',hist.t,'YData',hist.err);
            set(readout,'String',{ ...
                sprintf('t = %7.1f s   Visible sats: %2d / %d   iterations: %d',t,nv,P.nSat,it)
                sprintf('3-D position error : %6.2f m',err)
                sprintf('Clock bias est/true: %.1f / %.1f m',xhat(4),b)
                sprintf('GDOP %.2f  PDOP %.2f  HDOP %.2f  VDOP %.2f',dop.G,dop.P,dop.H,dop.V)});
        else
            set(readout,'String',{sprintf('t = %.1f s   Visible: %d  -> NO FIX (need >= 4)',t,nv)});
        end
    end

%% =====================================================================
%  SECTION 7 - GUI HELPER (nested so it can use the panel background)
%  =====================================================================
    function [s,v] = mkSlider(par,y,label,range,val,fmt)
        uicontrol(par,'Style','text','Units','normalized','String',label, ...
            'Position',[0.02 y 0.30 0.14],'HorizontalAlignment','left','BackgroundColor',bg);
        v = uicontrol(par,'Style','text','Units','normalized', ...
            'Position',[0.82 y 0.16 0.14],'String',sprintf(fmt,val),'BackgroundColor',bg);
        s = uicontrol(par,'Style','slider','Units','normalized','Min',range(1), ...
            'Max',range(2),'Value',val,'Position',[0.33 y+0.02 0.47 0.12], ...
            'Callback',@(src,~) set(v,'String',sprintf(fmt,src.Value)));
    end
end

%% =====================================================================
%  LOCAL FUNCTIONS - GPS MATHEMATICS (simulation logic)
%  =====================================================================
function s = satPositions(P,t)
% ECEF positions (3 x N) of circular-orbit satellites at time t. (Eq. 7)
u  = P.M0 + sqrt(P.mu/P.a^3)*t;                 % argument of latitude
cO = cos(P.raan); sO = sin(P.raan); ci = cos(P.inc); si = sin(P.inc);
x  = P.a*(cO.*cos(u) - sO.*ci.*sin(u));         % ECI coordinates
y  = P.a*(sO.*cos(u) + cO.*ci.*sin(u));
z  = P.a*si*sin(u);
th = P.we*t;                                    % Earth rotation angle
s  = [cos(th)*x + sin(th)*y; -sin(th)*x + cos(th)*y; z];   % ECI -> ECEF
end

function [x,G,it] = solvePosition(satV,rho,x0)
% Gauss-Newton least-squares solution for x = [xu;yu;zu;b]. (Eq. 3-5)
x = x0(:);
for it = 1:15
    d    = satV - x(1:3);                       % user -> satellite vectors
    r    = vecnorm(d);                          % predicted geometric ranges
    dRho = rho(:) - (r' + x(4));                % measured - predicted
    G    = [-(d./r)', ones(numel(r),1)];        % geometry matrix
    dx   = (G'*G) \ (G'*dRho);                  % normal equations
    x    = x + dx;                              % update estimate
    if norm(dx(1:3)) < 1e-4, break; end
end
end

function dop = computeDOP(G,Renu)
% Dilution of precision from the geometry matrix. (Eq. 6)
Q   = inv(G'*G);
Qe  = Renu*Q(1:3,1:3)*Renu';                    % position covariance in ENU
dop.G = sqrt(trace(Q));
dop.P = sqrt(trace(Q(1:3,1:3)));
dop.H = sqrt(Qe(1,1) + Qe(2,2));
dop.V = sqrt(Qe(3,3));
end
