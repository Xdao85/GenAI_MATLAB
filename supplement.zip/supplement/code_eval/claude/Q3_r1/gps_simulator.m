function gps_simulator
% GPS_SIMULATOR  Interactive GPS dynamics simulator (MATLAB R2019b or newer)
%
%   Run:  >> gps_simulator
%
%   * Tab "Equations"        : LaTeX-rendered GPS equations
%   * Tab "MATLAB Functions" : the code that implements each equation + explanation
%   * 3D view                : 24-satellite constellation (ECEF frame), user, pseudorange lines
%   * Bottom plot            : 3D position error and PDOP versus time
%
%   Sections of this file:
%     1. Constants and constellation definition
%     2. GUI design (figure, axes, tabs, controls)
%     3. LaTeX integration (equation tab)
%     4. Function documentation tab
%     5. Visualization objects (3D scene, error plot)
%     6. Simulation logic (callbacks, main loop, one time step)
%     7. Local math functions (the actual GPS equations)

%% ========================================================================
%  SECTION 1 - CONSTANTS AND CONSTELLATION DEFINITION
%  ========================================================================
c       = 299792458;          % speed of light [m/s]
Re      = 6371e3;             % mean Earth radius (spherical Earth) [m]
omegaE  = 7.2921151467e-5;    % Earth rotation rate [rad/s]
mu      = 3.986004418e14;     % Earth gravitational parameter [m^3/s^2]
Rorb    = 26560e3;            % GPS orbit radius [m]
inc     = deg2rad(55);        % GPS orbital inclination

% 24 satellites: 6 planes x 4 satellites (simplified Walker-like layout)
nPlanes = 6;  nPer = 4;  N = nPlanes*nPer;
orb.R   = Rorb;  orb.inc = inc;
orb.n   = sqrt(mu/Rorb^3);                 % mean motion [rad/s]
orb.Omega = zeros(1,N);  orb.u0 = zeros(1,N);
for k = 1:nPlanes
    for j = 1:nPer
        idx = (k-1)*nPer + j;
        orb.Omega(idx) = deg2rad(60*(k-1));                   % RAAN of the plane
        orb.u0(idx)    = deg2rad(90*(j-1) + 15*(k-1));        % phase along orbit
    end
end
orb.omegaE = omegaE;

% Simulation state (shared with the nested functions below)
simT = 0;  lat = 0;  lon = 0;  running = false;
histLen = 300;  tHist = nan(1,histLen);  eHist = nan(1,histLen);  dHist = nan(1,histLen);
trail = nan(3,400);

%% ========================================================================
%  SECTION 2 - GUI DESIGN (figure, panels, tabs, controls)
%  ========================================================================
fig = figure('Name','GPS Dynamics Simulator','NumberTitle','off', ...
    'Units','pixels','Position',[40 40 1420 830],'Color',[0.94 0.94 0.96], ...
    'CloseRequestFcn',@onClose);

% 3D scene axes (left, top)
ax3 = axes('Parent',fig,'Units','normalized','Position',[0.03 0.35 0.51 0.62]);

% Error / DOP axes (left, bottom)
axE = axes('Parent',fig,'Units','normalized','Position',[0.06 0.07 0.46 0.20]);

% Tab group on the right: equations + MATLAB function explanations
tabs   = uitabgroup(fig,'Units','normalized','Position',[0.56 0.45 0.42 0.52]);
tabEq  = uitab(tabs,'Title','Equations (LaTeX)');
tabFun = uitab(tabs,'Title','MATLAB Functions');

% Read-out box (live numbers)
readout = uicontrol(fig,'Style','text','Units','normalized', ...
    'Position',[0.56 0.335 0.42 0.105],'HorizontalAlignment','left', ...
    'FontName','Courier New','FontSize',9,'BackgroundColor',[1 1 1], ...
    'String',{'Press Start to begin the simulation.'});

% Control panel (buttons + sliders)
pnl = uipanel(fig,'Title','Simulation controls','Units','normalized', ...
    'Position',[0.56 0.01 0.42 0.31]);
btnStart = uicontrol(pnl,'Style','pushbutton','String','Start','Units','normalized', ...
    'Position',[0.02 0.80 0.20 0.17],'FontWeight','bold','Callback',@onStart);
uicontrol(pnl,'Style','pushbutton','String','Reset','Units','normalized', ...
    'Position',[0.24 0.80 0.20 0.17],'Callback',@onReset);

% label, [min max], default, display format
sWarp  = addSlider(pnl,1,'Time step [s/frame]',[10 300],100,'%.0f');
sSpeed = addSlider(pnl,2,'User speed [m/s]',[0 300],200,'%.0f');
sHead  = addSlider(pnl,3,'Heading [deg, 0=N]',[0 360],45,'%.0f');
sNoise = addSlider(pnl,4,'Range noise sigma [m]',[0 30],5,'%.1f');
sBias  = addSlider(pnl,5,'Receiver clock bias [us]',[0 1000],100,'%.0f');
sMask  = addSlider(pnl,6,'Elevation mask [deg]',[0 40],10,'%.0f');

%% ========================================================================
%  SECTION 3 - LaTeX INTEGRATION (equations drawn with the 'latex' interpreter)
%  ========================================================================
axEq = axes('Parent',tabEq,'Units','normalized','Position',[0 0 1 1],'Visible','off');
xlim(axEq,[0 1]);  ylim(axEq,[0 1]);

% Each row: {y-position, text, interpreter, font size, weight}
eqRows = { ...
 0.95, 'Pseudorange measurement',                              'tex',  12, 'bold'; ...
 0.88, "$\rho_i=\sqrt{(x_i-x)^2+(y_i-y)^2+(z_i-z)^2}+c\,\delta t+\varepsilon_i$", 'latex',15,'normal'; ...
 0.79, 'Linearised model about the estimate (x^, y^, z^, b^)', 'tex',  12, 'bold'; ...
 0.71, "$\Delta\rho_i=\mathbf{h}_i\,\Delta\mathbf{x},\ \ \mathbf{h}_i=\left[-\frac{x_i-\hat x}{\hat r_i},\,-\frac{y_i-\hat y}{\hat r_i},\,-\frac{z_i-\hat z}{\hat r_i},\,1\right]$", 'latex',14,'normal'; ...
 0.61, 'Least-squares position update (Gauss-Newton)',          'tex',  12, 'bold'; ...
 0.53, "$\Delta\mathbf{x}=(H^{T}H)^{-1}H^{T}\Delta\boldsymbol{\rho},\ \ \hat{\mathbf{x}}_{k+1}=\hat{\mathbf{x}}_k+\Delta\mathbf{x},\ \ \mathbf{x}=[x,y,z,b]^T,\ b=c\,\delta t$", 'latex',14,'normal'; ...
 0.43, 'Dilution of precision',                                'tex',  12, 'bold'; ...
 0.36, "$Q=(H^{T}H)^{-1},\ \ \mathrm{PDOP}=\sqrt{Q_{11}+Q_{22}+Q_{33}}$", 'latex',15,'normal'; ...
 0.26, 'Satellite orbit (circular) and Earth rotation',         'tex',  12, 'bold'; ...
 0.19, "$\mathbf{r}_{ECI}=R_z(\Omega)R_x(i)\,[r\cos u,\ r\sin u,\ 0]^T,\ u=u_0+nt,\ n=\sqrt{\mu/r^3}$", 'latex',13,'normal'; ...
 0.11, "$\mathbf{r}_{ECEF}=R_z(-\omega_e t)\,\mathbf{r}_{ECI}$, \ \ $El=\arcsin\frac{\hat{\mathbf{u}}\cdot(\mathbf{r}_s-\mathbf{r}_u)}{\|\mathbf{r}_s-\mathbf{r}_u\|}$", 'latex',14,'normal'; ...
 0.03, 'c = speed of light, \delta t = receiver clock bias, \epsilon = noise, H = geometry matrix', 'tex', 9, 'normal'};
for q = 1:size(eqRows,1)
    text(axEq,0.02,eqRows{q,1},eqRows{q,2},'Interpreter',eqRows{q,3}, ...
        'FontSize',eqRows{q,4},'FontWeight',eqRows{q,5},'VerticalAlignment','middle');
end

%% ========================================================================
%  SECTION 4 - MATLAB FUNCTION DOCUMENTATION TAB
%  ========================================================================
docs = buildDocs();
funList = uicontrol(tabFun,'Style','listbox','Units','normalized', ...
    'Position',[0.02 0.03 0.28 0.94],'String',{docs.name},'FontSize',10, ...
    'Callback',@onSelectDoc);
funText = uicontrol(tabFun,'Style','edit','Units','normalized','Max',2,'Min',0, ...
    'Position',[0.32 0.03 0.66 0.94],'HorizontalAlignment','left', ...
    'FontName','Courier New','FontSize',9,'Enable','inactive', ...
    'BackgroundColor',[1 1 1],'String',cellstr(docs(1).text));

%% ========================================================================
%  SECTION 5 - VISUALIZATION OBJECTS (3D scene + error plot)
%  ========================================================================
hold(ax3,'on');
[xs,ys,zs] = sphere(36);
surf(ax3,Re*xs/1e3,Re*ys/1e3,Re*zs/1e3,'FaceColor',[0.25 0.45 0.75], ...
    'FaceAlpha',0.85,'EdgeColor',[0.7 0.8 0.95],'EdgeAlpha',0.35);
% Satellite markers: visible (green) / below the horizon mask (grey)
hSatVis = plot3(ax3,NaN,NaN,NaN,'o','MarkerSize',8,'MarkerFaceColor',[0.1 0.8 0.2],'MarkerEdgeColor','k');
hSatHid = plot3(ax3,NaN,NaN,NaN,'o','MarkerSize',6,'MarkerFaceColor',[0.7 0.7 0.7],'MarkerEdgeColor',[0.4 0.4 0.4]);
hLbl = gobjects(1,N);
for i = 1:N
    hLbl(i) = text(ax3,0,0,0,sprintf(' G%d',i),'FontSize',7,'Color',[0.2 0.2 0.2]);
end
% Pseudorange lines (one per satellite; only visible ones are shown)
hLine = gobjects(1,N);
for i = 1:N
    hLine(i) = plot3(ax3,NaN,NaN,NaN,'-','Color',[1 0.8 0],'LineWidth',1,'Visible','off');
end
hTrail   = plot3(ax3,NaN,NaN,NaN,'-','Color',[1 1 1],'LineWidth',1.5);
hUser    = plot3(ax3,NaN,NaN,NaN,'s','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','k');
hEst     = plot3(ax3,NaN,NaN,NaN,'x','MarkerSize',12,'LineWidth',2,'Color','m');
axis(ax3,'equal');  grid(ax3,'on');  box(ax3,'on');  view(ax3,35,22);
set(ax3,'XLim',[-3.2e4 3.2e4],'YLim',[-3.2e4 3.2e4],'ZLim',[-3.2e4 3.2e4]);
xlabel(ax3,'X_{ECEF} [km]');  ylabel(ax3,'Y_{ECEF} [km]');  zlabel(ax3,'Z_{ECEF} [km]');
title(ax3,'GPS constellation, user (red square), estimate (magenta x), pseudoranges (yellow)');
legend(ax3,[hSatVis hSatHid hUser hEst],{'Visible sat','Below mask','True user','Estimated'},'Location','northeast');
rotate3d(ax3,'on');

% Error and PDOP versus time (two y-axes)
yyaxis(axE,'left');   hErr = plot(axE,NaN,NaN,'-','LineWidth',1.5);  ylabel(axE,'3D error [m]');
yyaxis(axE,'right');  hDop = plot(axE,NaN,NaN,'-','LineWidth',1.5);  ylabel(axE,'PDOP');
xlabel(axE,'Simulated time [min]');  grid(axE,'on');
title(axE,'Positioning error and satellite geometry (PDOP)');

% Initialise everything
resetState();
drawFrame();

%% ========================================================================
%  SECTION 6 - SIMULATION LOGIC (callbacks, main loop, single time step)
%  ========================================================================
    function onStart(~,~)                 % Start / Pause toggle
        if running
            running = false;  set(btnStart,'String','Start');
        else
            running = true;   set(btnStart,'String','Pause');
            while running && ishandle(fig)    % real-time animation loop
                stepSim();
                drawnow limitrate;
                pause(0.02);
            end
        end
    end

    function onReset(~,~)                 % Reset time, user position and plots
        resetState();  drawFrame();
    end

    function onClose(~,~)                 % Stop loop safely before closing
        running = false;  delete(fig);
    end

    function onSelectDoc(src,~)           % Show selected function description
        set(funText,'String',cellstr(docs(src.Value).text));
    end

    function resetState()
        simT = 0;  lat = deg2rad(30);  lon = deg2rad(100);   % start point (editable)
        tHist(:) = NaN;  eHist(:) = NaN;  dHist(:) = NaN;  trail(:) = NaN;
    end

    function stepSim()                    % ONE simulation step
        dt   = get(sWarp,'Value');        % simulated seconds per frame
        simT = simT + dt;
        % --- user motion on the sphere (constant speed and heading)
        v  = get(sSpeed,'Value');  az = deg2rad(get(sHead,'Value'));
        lat = lat + v*dt*cos(az)/Re;
        lat = max(min(lat,deg2rad(80)),-deg2rad(80));
        lon = lon + v*dt*sin(az)/(Re*cos(lat));
        drawFrame();
    end

    function drawFrame()                  % compute GPS solution + update graphics
        sigma = get(sNoise,'Value');  biasM = c*1e-6*get(sBias,'Value');
        mask  = get(sMask,'Value');

        ru = Re*[cos(lat)*cos(lon); cos(lat)*sin(lon); sin(lat)];   % true user ECEF
        S  = satECEF(simT,orb);                                      % 3xN satellite ECEF
        [vis,el] = visibility(S,ru,mask);                            %#ok<ASGLU>

        % --- satellites and labels
        set(hSatVis,'XData',S(1,vis)/1e3,'YData',S(2,vis)/1e3,'ZData',S(3,vis)/1e3);
        set(hSatHid,'XData',S(1,~vis)/1e3,'YData',S(2,~vis)/1e3,'ZData',S(3,~vis)/1e3);
        for i = 1:N
            set(hLbl(i),'Position',S(:,i)'/1e3);
        end

        % --- true-path trail
        trail = [trail(:,2:end), ru/1e3];
        set(hTrail,'XData',trail(1,:),'YData',trail(2,:),'ZData',trail(3,:));
        set(hUser,'XData',ru(1)/1e3,'YData',ru(2)/1e3,'ZData',ru(3)/1e3);

        % --- pseudorange lines (only to visible satellites)
        for i = 1:N
            if vis(i)
                set(hLine(i),'Visible','on','XData',[ru(1) S(1,i)]/1e3, ...
                    'YData',[ru(2) S(2,i)]/1e3,'ZData',[ru(3) S(3,i)]/1e3);
            else
                set(hLine(i),'Visible','off');
            end
        end

        % --- measurements and position solution
        nv = nnz(vis);
        if nv >= 4
            rho = pseudoranges(S(:,vis),ru,biasM,sigma);             % measurements
            [xhat,Q] = solveGPS(S(:,vis),rho);                       % least squares
            pEst = xhat(1:3);
            err  = pEst - ru;
            R    = ecef2enuRot(lat,lon);   enu = R*err;
            err3 = norm(err);
            pdop = sqrt(Q(1,1)+Q(2,2)+Q(3,3));
            set(hEst,'XData',pEst(1)/1e3,'YData',pEst(2)/1e3,'ZData',pEst(3)/1e3);
            latE = asind(pEst(3)/norm(pEst));  lonE = atan2d(pEst(2),pEst(1));
            txt = { sprintf('Time %7.1f min   Visible satellites: %d / %d',simT/60,nv,N), ...
                    sprintf('True  lat/lon : %9.4f, %9.4f deg',rad2deg(lat),rad2deg(lon)), ...
                    sprintf('Est.  lat/lon : %9.4f, %9.4f deg',latE,lonE), ...
                    sprintf('Error E/N/U   : %7.2f %7.2f %7.2f m  (3D %.2f m)',enu,err3), ...
                    sprintf('Clock bias    : est %.1f us / true %.1f us    PDOP %.2f',xhat(4)/c*1e6,biasM/c*1e6,pdop) };
        else
            err3 = NaN;  pdop = NaN;  set(hEst,'XData',NaN,'YData',NaN,'ZData',NaN);
            txt = { sprintf('Time %7.1f min   Visible satellites: %d / %d',simT/60,nv,N), ...
                    'Fewer than 4 satellites visible: no position fix.' };
        end
        set(readout,'String',txt);

        % --- error and PDOP history
        tHist = [tHist(2:end), simT/60];  eHist = [eHist(2:end), err3];  dHist = [dHist(2:end), pdop];
        set(hErr,'XData',tHist,'YData',eHist);
        set(hDop,'XData',tHist,'YData',dHist);
    end

    function sl = addSlider(parent,row,labelStr,rng,v0,fmt)   % GUI helper
        y = 0.64 - 0.12*(row-1);
        uicontrol(parent,'Style','text','Units','normalized','Position',[0.02 y 0.30 0.10], ...
            'String',labelStr,'HorizontalAlignment','left');
        val = uicontrol(parent,'Style','text','Units','normalized','Position',[0.80 y 0.18 0.10], ...
            'String',sprintf(fmt,v0));
        sl = uicontrol(parent,'Style','slider','Units','normalized','Min',rng(1),'Max',rng(2), ...
            'Value',v0,'Position',[0.33 y+0.01 0.45 0.09], ...
            'Callback',@(s,~) set(val,'String',sprintf(fmt,s.Value)));
    end
end  % ---- end of main function ----

%% ========================================================================
%  SECTION 7 - LOCAL MATH FUNCTIONS (implementation of the GPS equations)
%  ========================================================================

function S = satECEF(t,orb)
% Satellite positions in ECEF at time t [s]  (circular orbits).
%   u = u0 + n t ;  r_ECI = Rz(Omega) Rx(i) [R cos u; R sin u; 0]
%   r_ECEF = Rz(-omegaE t) r_ECI
u  = orb.u0 + orb.n*t;
ci = cos(orb.inc);  si = sin(orb.inc);
x  = orb.R*(cos(orb.Omega).*cos(u) - sin(orb.Omega).*ci.*sin(u));
y  = orb.R*(sin(orb.Omega).*cos(u) + cos(orb.Omega).*ci.*sin(u));
z  = orb.R*si.*sin(u);
th = orb.omegaE*t;                                  % Earth rotation angle
S  = [ x*cos(th) + y*sin(th); ...
      -x*sin(th) + y*cos(th); ...
       z ];
end

function [vis,el] = visibility(S,ru,maskDeg)
% Elevation angle of every satellite and visibility flag.
up = ru/norm(ru);                       % local vertical (spherical Earth)
d  = S - ru;                            % line-of-sight vectors
r  = sqrt(sum(d.^2,1));
el = asind((up'*d)./r);                 % elevation [deg]
vis = el >= maskDeg;
end

function rho = pseudoranges(Sv,ru,biasM,sigma)
% Pseudorange equation: rho_i = ||s_i - u|| + c*dt + eps_i
r   = sqrt(sum((Sv - ru).^2,1))';       % geometric ranges (column)
rho = r + biasM + sigma*randn(size(r)); % add clock bias [m] and noise
end

function [x,Q] = solveGPS(Sv,rho)
% Iterative least-squares solution for x = [X; Y; Z; b], b = c*dt.
n = numel(rho);
x = [0;0;0;0];                          % start at Earth centre
for k = 1:10
    d = Sv - x(1:3);                    % 3xn
    r = sqrt(sum(d.^2,1))';             % predicted ranges
    H = [-(d./r')', ones(n,1)];         % geometry matrix (n x 4)
    dRho = rho - (r + x(4));            % measurement residual
    dx = H\dRho;                        % least-squares step
    x  = x + dx;
    if norm(dx(1:3)) < 1e-4, break; end
end
Q = inv(H'*H);                          % cofactor matrix -> DOP
end

function R = ecef2enuRot(lat,lon)
% Rotation matrix from ECEF to local East-North-Up.
sl = sin(lat); cl = cos(lat); so = sin(lon); co = cos(lon);
R = [-so,      co,     0; ...
     -sl*co, -sl*so,  cl; ...
      cl*co,  cl*so,  sl];
end

function docs = buildDocs()
% Text shown in the "MATLAB Functions" tab (explanation + code).
docs(1).name = 'satECEF';
docs(1).text = [ ...
"satECEF(t, orb)  -  satellite positions";
"";
"Implements the circular-orbit equations. The argument of latitude";
"u = u0 + n*t advances with the mean motion n = sqrt(mu/R^3). The";
"orbit plane is tilted by inclination i and rotated by the RAAN Omega.";
"Finally the Earth rotation angle omegaE*t converts ECI to ECEF, so";
"satellites move relative to the rotating Earth.";
"";
"  u  = orb.u0 + orb.n*t;";
"  x  = R*(cos(Om).*cos(u) - sin(Om).*cos(i).*sin(u));";
"  y  = R*(sin(Om).*cos(u) + cos(Om).*cos(i).*sin(u));";
"  z  = R*sin(i).*sin(u);";
"  th = omegaE*t;";
"  S  = [x*cos(th)+y*sin(th); -x*sin(th)+y*cos(th); z];"];

docs(2).name = 'visibility';
docs(2).text = [ ...
"visibility(S, ru, maskDeg)  -  elevation test";
"";
"The vector from user to satellite is d = s - u. Its component along";
"the local vertical (up) divided by its length is sin(elevation).";
"Satellites below the elevation mask are not used in the solution.";
"";
"  up  = ru/norm(ru);";
"  d   = S - ru;";
"  r   = sqrt(sum(d.^2,1));";
"  el  = asind((up'*d)./r);";
"  vis = el >= maskDeg;"];

docs(3).name = 'pseudoranges';
docs(3).text = [ ...
"pseudoranges(Sv, ru, biasM, sigma)  -  measurement model";
"";
"Implements rho_i = sqrt((xi-x)^2+(yi-y)^2+(zi-z)^2) + c*dt + eps_i.";
"The geometric range is computed with sqrt/sum, the receiver clock";
"bias c*dt (metres) is common to all satellites, and eps_i is Gaussian";
"noise generated with randn (standard deviation sigma).";
"";
"  r   = sqrt(sum((Sv - ru).^2,1))';";
"  rho = r + biasM + sigma*randn(size(r));"];

docs(4).name = 'solveGPS';
docs(4).text = [ ...
"solveGPS(Sv, rho)  -  position calculation";
"";
"Gauss-Newton least squares. Unknowns: x = [X Y Z b] with b = c*dt.";
"Each iteration linearises the pseudorange equation: row i of H is";
"[-(xi-X)/ri, -(yi-Y)/ri, -(zi-Z)/ri, 1]. The residual dRho = rho -";
"(r + b) is mapped to a state correction with the backslash operator,";
"which solves dx = (H'H)^-1 H' dRho in a numerically stable way (QR).";
"At least 4 satellites are needed (4 unknowns).";
"";
"  d    = Sv - x(1:3);   r = sqrt(sum(d.^2,1))';";
"  H    = [-(d./r')', ones(n,1)];";
"  dRho = rho - (r + x(4));";
"  dx   = H\dRho;";
"  x    = x + dx;";
"  Q    = inv(H'*H);"];

docs(5).name = 'DOP (PDOP)';
docs(5).text = [ ...
"Dilution of precision (inside drawFrame)";
"";
"Q = (H'H)^-1 is the cofactor matrix returned by solveGPS. Its";
"diagonal terms scale the range error into position error. PDOP is";
"the square root of the trace of the 3x3 position block. Low PDOP =";
"satellites well spread in the sky = accurate fix.";
"";
"  pdop = sqrt(Q(1,1) + Q(2,2) + Q(3,3));"];

docs(6).name = 'ecef2enuRot';
docs(6).text = [ ...
"ecef2enuRot(lat, lon)  -  error in local axes";
"";
"The ECEF error vector (estimate - truth) is rotated into East, North,";
"Up components so that horizontal and vertical errors can be read.";
"";
"  R   = [-sin(lon)            cos(lon)           0;";
"         -sin(lat)*cos(lon)  -sin(lat)*sin(lon)  cos(lat);";
"          cos(lat)*cos(lon)   cos(lat)*sin(lon)  sin(lat)];";
"  enu = R*(pEst - ru);"];

docs(7).name = 'Animation loop';
docs(7).text = [ ...
"onStart / stepSim / drawFrame  -  real-time animation";
"";
"A while-loop runs while the 'running' flag is true. Each pass:";
"  1. advances simulated time by the 'Time step' slider value;";
"  2. moves the user along the chosen heading and speed;";
"  3. recomputes satellite ECEF positions (satECEF);";
"  4. builds pseudoranges and solves the position;";
"  5. updates line, marker and plot objects via set(...,'XData',...);";
"  6. drawnow limitrate; pause(0.02) refreshes the screen.";
"Updating existing graphics objects (instead of re-plotting) keeps";
"the animation fast. Rotate the 3D view with the mouse while it runs."];
end
