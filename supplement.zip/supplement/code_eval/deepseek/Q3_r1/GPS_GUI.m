function GPS_GUI
% =========================================================================
% GPS_GUI  -  Interactive GUI for simulating GPS technology dynamics
% -------------------------------------------------------------------------
% Features:
%   1. Displays GPS equations with LaTeX rendering in the GUI.
%   2. Shows the MATLAB functions used for each equation.
%   3. Animates 4 GPS satellites in 3D, a moving user, and live pseudoranges.
%   4. Fully commented: GUI design, LaTeX, simulation logic, visualization.
% =========================================================================

%% ------------------------- 1. GUI DESIGN ---------------------------------
% Create the main figure. We use 'Normalized' units so the GUI scales.
fig = figure('Name','GPS Technology Dynamics Simulator', ...
             'NumberTitle','off','Color',[0.10 0.10 0.14], ...
             'Units','normalized','Position',[0.05 0.05 0.9 0.85], ...
             'MenuBar','none','ToolBar','none');

% ---- Left panel: equation display (LaTeX) -------------------------------
eqPanel = uipanel(fig,'Title','GPS Equations (LaTeX)', ...
    'Units','normalized','Position',[0.01 0.55 0.30 0.44], ...
    'BackgroundColor',[0.15 0.15 0.20],'ForegroundColor','w', ...
    'FontSize',11);

% Axes used only as a canvas for the LaTeX text object.
eqAx = axes(eqPanel,'Units','normalized','Position',[0 0 1 1], ...
    'Color',[0.15 0.15 0.20],'XColor','none','YColor','none');
axis(eqAx,[0 1 0 1]); hold(eqAx,'on');

% LaTeX strings (use $$...$$ for MATLAB's built-in LaTeX interpreter).
eq1 = ['$$\rho_i = \| \mathbf{r}_u - \mathbf{r}_i \| ' ...
       '+ c\,\delta t_u - c\,\delta t_i + \varepsilon_i$$'];
eq2 = ['$$\mathbf{r}_u = (A^{T}A)^{-1}A^{T}\mathbf{b}, ' ...
       '\quad A = \begin{bmatrix}\hat{u}_1^{T} & 1\\ \vdots & \vdots\\ ' ...
       '\hat{u}_n^{T} & 1\end{bmatrix}$$'];
eq3 = ['$$\hat{u}_i = \frac{\mathbf{r}_u - \mathbf{r}_i}' ...
       '{\|\mathbf{r}_u - \mathbf{r}_i\|}$$'];

text(eqAx,0.5,0.85,eq1,'Interpreter','latex','Color','w', ...
     'FontSize',13,'HorizontalAlignment','center');
text(eqAx,0.5,0.55,eq2,'Interpreter','latex','Color','w', ...
     'FontSize',13,'HorizontalAlignment','center');
text(eqAx,0.5,0.25,eq3,'Interpreter','latex','Color','w', ...
     'FontSize',13,'HorizontalAlignment','center');

% ---- Bottom-left panel: function explainer ------------------------------
fnPanel = uipanel(fig,'Title','MATLAB Functions Used', ...
    'Units','normalized','Position',[0.01 0.05 0.30 0.48], ...
    'BackgroundColor',[0.15 0.15 0.20],'ForegroundColor','w','FontSize',11);

fnText = sprintf([ ...
    'latex   : Render LaTeX strings inside GUI text\n' ...
    'norm    : Euclidean distance for pseudorange\n' ...
    'inv / \\ : Solve weighted least-squares position\n' ...
    'exp     : Exponential decay for clock bias drift\n' ...
    'plot3   : Draw 3-D satellite/pseudorange lines\n' ...
    'drawnow : Refresh figure each animation step\n' ...
    'pause   : Control simulation frame rate\n' ...
    'randn   : Add Gaussian measurement noise\n' ...
    'cross   : Compute satellite line-of-sight vectors']);

uicontrol(fnPanel,'Style','text','Units','normalized', ...
    'Position',[0.02 0.02 0.96 0.96],'String',fnText, ...
    'HorizontalAlignment','left','BackgroundColor',[0.15 0.15 0.20], ...
    'ForegroundColor',[0.85 0.95 1.0],'FontName','Consolas','FontSize',10);

% ---- Right panel: 3D animation axes -------------------------------------
ax = axes(fig,'Units','normalized','Position',[0.34 0.22 0.64 0.76], ...
    'Color',[0.05 0.05 0.10],'XColor','w','YColor','w','ZColor','w', ...
    'GridColor',[0.4 0.4 0.4]);
title(ax,'GPS Constellation & User Position','Color','w','FontSize',12);
xlabel(ax,'X (m)'); ylabel(ax,'Y (m)'); zlabel(ax,'Z (m)');
axis(ax,[-3e7 3e7 -3e7 3e7 -3e7 3e7]); grid(ax,'on'); view(ax,35,25);
hold(ax,'on');

% Earth sphere for reference
[Xe,Ye,Ze] = sphere(30);
surf(ax,6.371e6*Xe,6.371e6*Ye,6.371e6*Ze, ...
    'FaceColor',[0.15 0.35 0.65],'EdgeColor','none','FaceAlpha',0.9);

% ---- Bottom control panel ----------------------------------------------
uicontrol(fig,'Style','pushbutton','String','Start / Pause', ...
    'Units','normalized','Position',[0.34 0.06 0.15 0.07], ...
    'BackgroundColor',[0.2 0.6 0.3],'ForegroundColor','w', ...
    'FontSize',11,'Callback',@toggleRun);

uicontrol(fig,'Style','pushbutton','String','Reset', ...
    'Units','normalized','Position',[0.51 0.06 0.15 0.07], ...
    'BackgroundColor',[0.6 0.3 0.2],'ForegroundColor','w', ...
    'FontSize',11,'Callback',@resetSim);

statusH = uicontrol(fig,'Style','text','String','Status: Ready', ...
    'Units','normalized','Position',[0.68 0.06 0.30 0.07], ...
    'BackgroundColor',[0.15 0.15 0.20],'ForegroundColor','w', ...
    'FontSize',11,'HorizontalAlignment','left');

%% --------------------- 2. INITIALISE SIMULATION STATE -------------------
state.running  = false;     % flag toggled by Start/Pause button
state.speed    = 0.05;      % seconds of sim time per frame
state.t        = 0;         % simulation clock

% ---- Satellite constellation (4 satellites on high orbits) --------------
% Each row: [radius(m), inclination(rad), RAAN(rad), phase(rad)]
constellation = [ ...
    2.656e7, 55*pi/180,  30*pi/180, 0.0;
    2.656e7, 55*pi/180, 120*pi/180, 1.5;
    2.656e7, 55*pi/180, 210*pi/180, 3.0;
    2.656e7, 55*pi/180, 300*pi/180, 4.5];
state.constellation = constellation;

% ---- Visual handles (so we can update rather than redraw) ---------------
colors = lines(4);
hSat   = gobjects(1,4);
hLine  = gobjects(1,4);
for k = 1:4
    hSat(k)  = plot3(ax,0,0,0,'^','MarkerSize',12, ...
                     'MarkerFaceColor',colors(k,:),'MarkerEdgeColor','w');
    hLine(k) = plot3(ax,[0 0],[0 0],[0 0],'--','Color',colors(k,:), ...
                     'LineWidth',1.2);
end
hUser = plot3(ax,0,0,0,'o','MarkerSize',11,'MarkerFaceColor','y', ...
              'MarkerEdgeColor','k','LineWidth',1.5);

% User trajectory: circular ground track
Rearth = 6.371e6;
state.userR = Rearth + 2e4;                 % ~20 km altitude
state.userOmega = 1e-3;                     % angular speed

% Store handles in state for callbacks
state.hSat = hSat; state.hLine = hLine; state.hUser = hUser;
state.ax = ax; state.statusH = statusH;

% Persist state in the figure's UserData
setappdata(fig,'state',state);

%% ------------------------- 3. START THE LOOP ----------------------------
% Use a timer instead of a blocking while-loop so the GUI stays responsive.
tObj = timer('ExecutionMode','fixedRate','Period',0.05, ...
             'TimerFcn',@(~,~)simStep(fig));
setappdata(fig,'timer',tObj);

% Nested callbacks ---------------------------------------------------------
    function toggleRun(~,~)
        s = getappdata(fig,'state');
        s.running = ~s.running;
        setappdata(fig,'state',s);
        if s.running
            start(tObj);
            set(s.statusH,'String','Status: Running');
        else
            stop(tObj);
            set(s.statusH,'String','Status: Paused');
        end
    end

    function resetSim(~,~)
        stop(tObj);
        s = getappdata(fig,'state');
        s.t = 0; s.running = false;
        setappdata(fig,'state',s);
        set(s.statusH,'String','Status: Reset');
    end
end

%% --------------------- 4. SIMULATION STEP (animation) -------------------
function simStep(fig)
% Called by the timer. Advances the simulation by one frame and updates
% every graphical object in place.

s = getappdata(fig,'state');
if ~s.running, return; end

% --- 4a. Advance clock & user position -----------------------------------
s.t = s.t + s.speed;
theta = s.userOmega * s.t;
Ru = s.userR;
user = [Ru*cos(theta); Ru*sin(theta); 0.2*Ru*sin(2*theta)]; % 3-D path

% --- 4b. Satellite positions from orbital elements -----------------------
c = 299792458;                    % speed of light (m/s)
satPos = zeros(3,4);
for k = 1:4
    a     = s.constellation(k,1);
    inc   = s.constellation(k,2);
    raan  = s.constellation(k,3);
    phase = s.constellation(k,4) + 1e-4*s.t;  % slow orbital motion
    % Position in orbital plane
    p = a*[cos(phase); sin(phase); 0];
    % Rotate by inclination about x, then by RAAN about z
    Rx = [1 0 0; 0 cos(inc) -sin(inc); 0 sin(inc) cos(inc)];
    Rz = [cos(raan) -sin(raan) 0; sin(raan) cos(raan) 0; 0 0 1];
    satPos(:,k) = Rz*Rx*p;
end

% --- 4c. Compute pseudoranges (with noise + clock bias) ------------------
% Pseudorange equation:  rho = ||ru - ri|| + c*dtu - c*dti + noise
dtu = 1e-6*sin(0.1*s.t);          % user clock bias drift
rho = zeros(1,4);
for k = 1:4
    geometric = norm(user - satPos(:,k));   % MATLAB 'norm'
    noise     = 3*randn;                    % ~3 m Gaussian noise
    rho(k)    = geometric + c*dtu + noise;  % pseudorange
end

% --- 4d. Solve for user position (least squares) -------------------------
% Linearise: drho = A * [dx dy dz dtu]^T
A = zeros(4,4); b = zeros(4,1);
for k = 1:4
    uhat = (user - satPos(:,k)) / norm(user - satPos(:,k)); % unit LOS
    A(k,1:3) = -uhat.';         % partial wrt user position
    A(k,4)   = c;               % partial wrt clock bias
    b(k)     = rho(k) - norm(user - satPos(:,k)) - c*dtu;
end
delta = A\b;                    % MATLAB backslash -> least squares
estPos = user + delta(1:3);     % corrected estimate

% --- 4e. Update graphics (in-place, no redraw) ---------------------------
for k = 1:4
    set(s.hSat(k),'XData',satPos(1,k),'YData',satPos(2,k), ...
                  'ZData',satPos(3,k));
    set(s.hLine(k),'XData',[satPos(1,k) user(1)], ...
                   'YData',[satPos(2,k) user(2)], ...
                   'ZData',[satPos(3,k) user(3)]);
end
set(s.hUser,'XData',estPos(1),'YData',estPos(2),'ZData',estPos(3));

% Update status with live diagnostics
set(s.statusH,'String',sprintf( ...
    't = %6.1f s |  rho = [%5.1f %5.1f %5.1f %5.1f] x10^6 m |  err = %.1f m', ...
    s.t, rho/1e6, norm(estPos - user)));

drawnow limitrate;              % refresh figure without backlog

setappdata(fig,'state',s);
end