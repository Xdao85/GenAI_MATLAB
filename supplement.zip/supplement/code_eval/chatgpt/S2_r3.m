%% Finite straight conductor: magnetic field at an observation point
% Undergraduate EM course example
% SI units throughout.
%
% Geometry:
%   Wire length l = 2 m
%   Current I = 1 A in the +z direction
%   Wire center A = (0.25, 0.50, 0) m
%   Wire extends from z = -1 m to z = +1 m
%   Observation point P = (1, 1, 0) m
%
% The magnetic field is computed in two independent ways:
%   1) Closed-form finite-wire formula
%   2) Numerical Biot-Savart integration
%
% The script also checks the right-hand rule and compares the two
% numerical results.

clear;
clc;
close all;

%% Constants and geometry

mu0 = 4*pi*1e-7;       % Permeability of free space [H/m]
I = 1.0;               % Current [A]
l = 2.0;               % Wire length [m]

A = [0.25, 0.50, 0.0]; % Wire center [m]
P = [1.0, 1.0, 0.0];   % Observation point [m]

z1 = -l/2;             % Lower z coordinate relative to A [m]
z2 =  l/2;             % Upper z coordinate relative to A [m]

%% Calculate B using the closed-form finite-wire formula

B_ref = magneticFieldClosedForm(mu0, I, A, P, z1, z2);

%% Calculate B independently using numerical Biot-Savart integration

N = 100000;            % Number of integration segments
B_num = magneticFieldNumerical(mu0, I, A, P, z1, z2, N);

%% Compare the two results

vectorError = norm(B_num - B_ref) / norm(B_ref);

fprintf('Finite straight conductor magnetic field\n');
fprintf('----------------------------------------\n');
fprintf('Wire center A = [%.4f, %.4f, %.4f] m\n', A);
fprintf('Observation P = [%.4f, %.4f, %.4f] m\n', P);
fprintf('Current I     = %.4f A in +z direction\n', I);
fprintf('Wire length   = %.4f m\n\n', l);

fprintf('Closed-form B_ref [T]:\n');
fprintf('  [%.8e, %.8e, %.8e]\n\n', B_ref);

fprintf('Numerical B_num [T]:\n');
fprintf('  [%.8e, %.8e, %.8e]\n\n', B_num);

fprintf('Relative vector error = %.8e (%.6f %%)\n', ...
    vectorError, 100*vectorError);

%% Check the right-hand rule

% For current in +z, the magnetic field circles the z axis according
% to the right-hand rule.  At P, the radial direction from the wire
% center toward P is proportional to [dx, dy, 0].
%
% The expected tangential direction is:
%     phi_hat = z_hat x rho_hat
%
% where z_hat = [0, 0, 1].

rho = [P(1)-A(1), P(2)-A(2), 0];
rho_hat = rho / norm(rho);
z_hat = [0, 0, 1];

% Equation: phi_hat = z_hat x rho_hat
phi_hat = cross(z_hat, rho_hat);

% Normalize the calculated numerical field direction.
B_hat = B_num / norm(B_num);

% Dot product near +1 means that B points in the expected
% right-hand-rule direction.
RHR_dot = dot(B_hat, phi_hat);

fprintf('\nRight-hand-rule check:\n');
fprintf('Expected direction = [%.6f, %.6f, %.6f]\n', phi_hat);
fprintf('Numerical B direction = [%.6f, %.6f, %.6f]\n', B_hat);
fprintf('Direction dot product = %.8f\n', RHR_dot);

if RHR_dot > 0.999
    fprintf('PASS: B direction agrees with the right-hand rule.\n');
else
    fprintf('FAIL: B direction does not agree with the right-hand rule.\n');
end

%% Error tolerance check

% Required relative vector error is less than or equal to 0.1 percent.
errorLimit = 0.001;

if vectorError > errorLimit
    error(['STOP: The numerical vector error is %.6f %%, ' ...
           'which exceeds the 0.1 %% limit.'], 100*vectorError);
end

fprintf('\nPASS: Relative vector error is below 0.1 %%.\n');

%% Plot the wire, A, P, and B

plotGeometry(A, P, z1, z2, B_num);


%% Local function: closed-form solution
function B = magneticFieldClosedForm(mu0, I, A, P, z1, z2)
% magneticFieldClosedForm computes B from the closed-form finite-wire
% Biot-Savart expression.
%
% The conductor is parallel to the z axis and carries current in +z.
%
% Let:
%   dx = Px - Ax
%   dy = Py - Ay
%   rho^2 = dx^2 + dy^2
%
% For a current element located at z, the Biot-Savart differential
% field is:
%
%   dB = (mu0*I/(4*pi)) * (dl x R) / |R|^3
%
% For dl = dz*z_hat and
% R = [dx, dy, -z], integration along z gives a field perpendicular
% to the radial vector:
%
%   B = (mu0*I/(4*pi*rho^2)) * [dy, -dx, 0] *
%       ( z2/sqrt(rho^2 + z2^2) - z1/sqrt(rho^2 + z1^2) )
%
% The sign follows from the +z current direction and the cross product
% dl x R.

dx = P(1) - A(1);
dy = P(2) - A(2);

% Equation: rho^2 = dx^2 + dy^2
rho2 = dx^2 + dy^2;

% Equation: F = z2/sqrt(rho^2+z2^2) - z1/sqrt(rho^2+z1^2)
F = z2 / sqrt(rho2 + z2^2) ...
  - z1 / sqrt(rho2 + z1^2);

% Equation:
% B = (mu0*I/(4*pi*rho^2)) * [dy, -dx, 0] * F
B = (mu0*I/(4*pi*rho2)) * [dy, -dx, 0] * F;

end


%% Local function: numerical Biot-Savart solution
function B = magneticFieldNumerical(mu0, I, A, P, z1, z2, N)
% magneticFieldNumerical computes B by directly integrating the
% Biot-Savart law numerically.
%
% The Biot-Savart equation is:
%
%   dB = (mu0*I/(4*pi)) * (dl x R) / |R|^3
%
% For this wire:
%
%   dl = [0, 0, dz]
%
% and the source point is:
%
%   r' = A + [0, 0, z]
%
% Therefore:
%
%   R = P - r'
%
% The integral is evaluated with the midpoint rule over N segments.

dz = (z2 - z1) / N;

B = [0, 0, 0];

for k = 1:N

    % Midpoint coordinate of the kth source segment.
    zmid = z1 + (k - 0.5)*dz;

    % Source point on the conductor.
    r_source = A + [0, 0, zmid];

    % Equation: R = P - r_source
    R = P - r_source;

    % Equation: |R| = sqrt(R dot R)
    Rmag = norm(R);

    % Differential current path vector:
    % dl = [0, 0, dz]
    dl = [0, 0, dz];

    % Equation:
    % dB = (mu0*I/(4*pi)) * (dl x R) / |R|^3
    dB = (mu0*I/(4*pi)) * cross(dl, R) / Rmag^3;

    % Numerical integration by summing all differential fields.
    B = B + dB;
end

end


%% Local function: geometry and magnetic-field plot
function plotGeometry(A, P, z1, z2, B)
% plotGeometry plots the finite wire, its center A, observation point P,
% and the magnetic field vector at P.

figure('Color', 'w');
hold on;
grid on;

% Wire coordinates.
z = linspace(z1, z2, 100);

xwire = A(1) * ones(size(z));
ywire = A(2) * ones(size(z));
zwire = A(3) + z;

% Plot the wire.
plot3(xwire, ywire, zwire, 'k-', 'LineWidth', 3);

% Plot the wire center A.
plot3(A(1), A(2), A(3), 'ko', ...
    'MarkerSize', 8, 'MarkerFaceColor', 'k');

% Plot observation point P.
plot3(P(1), P(2), P(3), 'ro', ...
    'MarkerSize', 8, 'MarkerFaceColor', 'r');

% Scale the displayed B vector so that it is visible in the geometry.
% The physical field is still B; this scale only affects the drawing.
BplotScale = 1e6;

% Plot B using quiver3.
quiver3(P(1), P(2), P(3), ...
    BplotScale*B(1), BplotScale*B(2), BplotScale*B(3), ...
    0, 'LineWidth', 2, 'MaxHeadSize', 0.5);

% Label the points.
text(A(1), A(2), A(3), '  A');
text(P(1), P(2), P(3), '  P');

xlabel('x (m)');
ylabel('y (m)');
zlabel('z (m)');

title('Finite Straight Conductor and Magnetic Field');

legend('Wire', 'A: wire center', 'P: observation point', ...
    'B at P (scaled)', 'Location', 'best');

axis equal;
view(3);

hold off;

end